"""Hybrid KapraoTiny: the existing classifier picks the category (or refuses),
then a small decoder-only Transformer writes the answer for that category.
A guard falls back to the fixed answer when the generated text drifts from
the knowledge base. kaprao.py and kaprao_model.pt are not modified."""
import argparse
import difflib
import hashlib
import itertools
import json
import math
import random
import re
from pathlib import Path

import torch
from torch import nn

import kaprao
from answer_variants import ANSWER_VARIANTS as BASE_VARIANTS
from dataset_en import ANSWERS_EN, EN_FRAGMENTS
from dataset_v2 import NEW_KNOWLEDGE
from gen_fragments import FRAGMENTS

BASE = Path(__file__).resolve().parent
GEN_PATH = BASE / 'kaprao_gen.pt'
SPECIAL = ['<pad>', '<unk>', '<bos>', '<sep>', '<eos>']
PAD, UNK, BOS, SEP, EOS = range(len(SPECIAL))
GEN_CONFIG = {'dim': 192, 'layers': 4, 'heads': 4, 'ffn': 512, 'max_len': 256}
MAX_QUESTION = 64
MAX_ANSWER = 170
# Hand-written paraphrases per answer ID (the first one is the classifier's fixed answer).
# ID 16 is the refusal class, which the generator never writes.
WRITTEN_VARIANTS = {**dict(enumerate(BASE_VARIANTS)), **{kaprao.UNKNOWN_ANSWER_ID + 1 + i: item['variants'] for i, item in enumerate(NEW_KNOWLEDGE)}}


def held_out(text):
    # Stable 25% of clause combinations never used for training, to measure new sentences.
    return hashlib.sha256(text.encode('utf-8')).digest()[0] % 4 == 0


def clause_combinations(answer_id, fragments=FRAGMENTS):
    return list(dict.fromkeys(''.join(parts) for parts in itertools.product(*fragments[answer_id])))


def split_variants(written, fragments):
    # Training targets: written paraphrases plus 75% of the clause combinations;
    # held out: the other 25%, valid sentences the model never trains on.
    train = {i: list(dict.fromkeys(v + [c for c in clause_combinations(i, fragments) if not held_out(c) and c not in v])) for i, v in written.items()}
    held = {i: [c for c in clause_combinations(i, fragments) if held_out(c) and c not in written[i]] for i in written}
    return train, held


LANGUAGES = ('th', 'en')
# Thai (ANSWER_VARIANTS[i][0] is the classifier's fixed Thai answer) and English variants.
ANSWER_VARIANTS, HELD_OUT_VARIANTS = split_variants(WRITTEN_VARIANTS, FRAGMENTS)
ANSWER_VARIANTS_EN, HELD_OUT_VARIANTS_EN = split_variants({i: [ANSWERS_EN[i]] for i in WRITTEN_VARIANTS}, EN_FRAGMENTS)
TRAIN_VARIANTS = {'th': ANSWER_VARIANTS, 'en': ANSWER_VARIANTS_EN}
HELD_OUT = {'th': HELD_OUT_VARIANTS, 'en': HELD_OUT_VARIANTS_EN}
# The guard accepts only these verified sentences, seen in training or held out.
GUARD_VARIANTS = {lang: {i: TRAIN_VARIANTS[lang][i] + HELD_OUT[lang][i] for i in WRITTEN_VARIANTS} for lang in LANGUAGES}
GUARD_SETS = {lang: {i: set(v) for i, v in GUARD_VARIANTS[lang].items()} for lang in LANGUAGES}
CLASS_IDS = sorted(ANSWER_VARIANTS)


def guard_accepts(text, finished, answer_id, lang='th'):
    return finished and text in GUARD_SETS[lang][answer_id]
# The guard shows generated text only when it is exactly one of the verified sentences for
# its category (seen in training or held out). A similarity threshold let one-word fact swaps
# and typos through. With sampling, the generator gets a few attempts before the fallback.
GUARD_ATTEMPTS = 3


ASCII_WORD = re.compile(r'[A-Za-z]+')


def gen_tokenize(text):
    # Like kaprao.tokenize, but keeps single spaces and letter case so the generator can write them.
    # English words (ASCII letter runs) are single tokens.
    text = re.sub(r'\s+', ' ', text.strip().replace('กระเพรา', 'กะเพรา'))
    tokens, i = [], 0
    while i < len(text):
        word = ASCII_WORD.match(text, i)
        term = word.group() if word else next((w for w in kaprao.LEXICON if text.startswith(w, i)), None) or text[i]
        tokens.append(term)
        i += len(term)
    return tokens


def class_token(answer_id):
    return f'<c{answer_id}>'


def build_vocab(train_rows):
    terms = set()
    for row in train_rows:
        terms.update(gen_tokenize(row['question']))
    for lang in LANGUAGES:
        for variants in TRAIN_VARIANTS[lang].values():
            for answer in variants:
                terms.update(gen_tokenize(answer))
    classes = [class_token(i) for i in CLASS_IDS]
    # Language tokens follow the class tokens; the generator never writes either.
    return {s: i for i, s in enumerate(SPECIAL + classes + [f'<{lang}>' for lang in LANGUAGES] + sorted(terms))}


def prompt_ids(question, answer_id, vocab, lang=None):
    q = [vocab.get(t, UNK) for t in gen_tokenize(question)][:MAX_QUESTION]
    return [BOS, vocab[class_token(answer_id)], vocab[f'<{lang or kaprao.language(question)}>']] + q + [SEP]


class TinyGPT(nn.Module):
    """Decoder-only Transformer: the same encoder layers as the classifier, with a causal mask."""

    def __init__(self, vocab_size, dim=192, layers=4, heads=4, ffn=512, max_len=192):
        super().__init__()
        self.token = nn.Embedding(vocab_size, dim, padding_idx=PAD)
        self.position = nn.Embedding(max_len, dim)
        block = nn.TransformerEncoderLayer(dim, heads, ffn, dropout=0.1, batch_first=True, norm_first=True)
        self.blocks = nn.TransformerEncoder(block, layers, norm=nn.LayerNorm(dim), enable_nested_tensor=False)
        self.head = nn.Linear(dim, vocab_size, bias=False)
        self.head.weight = self.token.weight  # weight tying keeps the model small
        self.max_len = max_len
        nn.init.normal_(self.token.weight, std=0.02)
        nn.init.normal_(self.position.weight, std=0.02)

    def forward(self, ids):
        length = ids.size(1)
        pos = torch.arange(length, device=ids.device)
        causal = torch.triu(torch.full((length, length), float('-inf'), device=ids.device), 1)
        x = self.token(ids) * math.sqrt(self.token.embedding_dim) + self.position(pos)[None]
        x = self.blocks(x, mask=causal, is_causal=True)
        return self.head(x)


def make_examples(rows, vocab):
    # (question, answer_id, language) for known categories only; refusals stay with the classifier.
    return [(r['question'], r['answer_id'], kaprao.language(r['question'])) for r in rows if r['answer_id'] in ANSWER_VARIANTS]


def batch_tensors(pairs, vocab):
    seqs, targets = [], []
    for question, answer_id, lang, answer in pairs:
        prompt = prompt_ids(question, answer_id, vocab, lang)
        reply = [vocab.get(t, UNK) for t in gen_tokenize(answer)][:MAX_ANSWER] + [EOS]
        seq = prompt + reply
        # Loss only on the answer part, so the model learns to write answers, not questions.
        target = [-100] * (len(prompt) - 1) + reply
        seqs.append(seq[:-1])
        targets.append(target)
    width = max(map(len, seqs))
    ids = torch.tensor([s + [PAD] * (width - len(s)) for s in seqs])
    labels = torch.tensor([t + [-100] * (width - len(t)) for t in targets])
    return ids, labels


def validation_loss(model, examples, vocab):
    model.eval()
    total, count = 0.0, 0
    with torch.no_grad():
        for start in range(0, len(examples), 32):
            chunk = examples[start:start + 32]
            pairs = [(q, a, lang, TRAIN_VARIANTS[lang][a][0]) for q, a, lang in chunk]
            ids, labels = batch_tensors(pairs, vocab)
            logits = model(ids)
            total += nn.functional.cross_entropy(logits.reshape(-1, logits.size(-1)), labels.reshape(-1), ignore_index=-100, reduction='sum').item()
            count += labels.ne(-100).sum().item()
    return total / count


def train(args):
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.set_num_threads(min(4, torch.get_num_threads()))
    data = kaprao.load_data()
    vocab = build_vocab(data['train'])
    train_examples = make_examples(data['train'], vocab)
    val_examples = make_examples(data['validation'], vocab)
    model = TinyGPT(len(vocab), **GEN_CONFIG)
    print(f'Generator parameters: {sum(p.numel() for p in model.parameters()):,}; vocab: {len(vocab)}', flush=True)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.01)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=args.lr * 0.1)
    best, history = float('inf'), []
    for epoch in range(1, args.epochs + 1):
        model.train()
        random.shuffle(train_examples)
        total, steps = 0.0, 0
        for start in range(0, len(train_examples), args.batch_size):
            chunk = train_examples[start:start + args.batch_size]
            # A different paraphrase each time, so the model learns several ways to say each answer.
            pairs = [(q, a, lang, random.choice(TRAIN_VARIANTS[lang][a])) for q, a, lang in chunk]
            ids, labels = batch_tensors(pairs, vocab)
            logits = model(ids)
            loss = nn.functional.cross_entropy(logits.reshape(-1, logits.size(-1)), labels.reshape(-1), ignore_index=-100)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            total, steps = total + loss.item(), steps + 1
        scheduler.step()
        val = validation_loss(model, val_examples, vocab)
        history.append({'epoch': epoch, 'train_loss': total / steps, 'validation_loss': val})
        if epoch % 5 == 0 or epoch == 1:
            print(f'Epoch {epoch}: loss={total / steps:.4f}, validation_loss={val:.4f}', flush=True)
        if val < best:
            best = val
            torch.save({'model': model.state_dict(), 'config': GEN_CONFIG, 'vocab': vocab, 'epoch': epoch, 'seed': args.seed, 'dataset_sha256': kaprao.fingerprint(data)}, GEN_PATH)
    (BASE / 'gen_training_history.json').write_text(json.dumps(history, indent=2), encoding='utf-8')
    saved = torch.load(GEN_PATH, map_location='cpu', weights_only=True)
    print(f"Saved {GEN_PATH.name} from epoch {saved['epoch']}; validation_loss={best:.4f}", flush=True)


def loaded_generator():
    checkpoint = torch.load(GEN_PATH, map_location='cpu', weights_only=True)
    model = TinyGPT(len(checkpoint['vocab']), **checkpoint['config'])
    model.load_state_dict(checkpoint['model'])
    model.eval()
    return model, checkpoint


def generate(model, vocab, question, answer_id, temperature=0.0, generator=None):
    inverse = {i: t for t, i in vocab.items()}
    ids = prompt_ids(question, answer_id, vocab)
    blocked = len(SPECIAL) + len(CLASS_IDS) + len(LANGUAGES)
    out = []
    with torch.no_grad():
        for _ in range(MAX_ANSWER):
            logits = model(torch.tensor([ids[-model.max_len:]]))[0, -1]
            logits[[PAD, UNK, BOS, SEP]] = float('-inf')
            logits[len(SPECIAL):blocked] = float('-inf')
            if temperature > 0:
                token = torch.multinomial((logits / temperature).softmax(-1), 1, generator=generator).item()
            else:
                token = int(logits.argmax())
            if token == EOS:
                return ''.join(inverse[t] for t in out).strip(), True
            out.append(token)
            ids.append(token)
    return ''.join(inverse[t] for t in out).strip(), False


def similarity(text, answer_id, lang='th'):
    # Diagnostic only (the guard is an exact match). autojunk off so C++ can match it at any length.
    return max(difflib.SequenceMatcher(None, text, v, autojunk=False).ratio() for v in GUARD_VARIANTS[lang][answer_id])


def ask(question, classifier, cls_checkpoint, generator, gen_checkpoint, temperature=0.0, detail=False):
    """Returns the reply text; with detail=True also returns how it was produced."""
    greeting = kaprao.is_greeting(question)
    question = question if greeting else kaprao.strip_greeting(question)
    lang = kaprao.language(question)
    text_for = kaprao.messages(lang)
    info = {'source': 'classifier', 'language': lang}
    if greeting:
        reply, info['source'] = text_for['greeting'], 'greeting'
    elif kaprao.is_help(question):
        reply, info['source'] = text_for['help'], 'help'
    elif not kaprao.tokenize(question):
        reply = text_for['empty']
    elif not kaprao.is_in_scope(question, classifier.max_len):
        reply = text_for['out_of_scope']
    else:
        ids = torch.tensor([kaprao.encode(question, cls_checkpoint['vocab'], classifier.max_len)])
        with torch.no_grad():
            confidence, index = classifier(ids).softmax(1)[0].max(0)
        answer_id, confidence = index.item(), confidence.item()
        info.update(answer_id=answer_id, confidence=confidence)
        if answer_id == cls_checkpoint.get('unknown_answer_id'):
            reply = kaprao.answer_text(cls_checkpoint, answer_id, lang)
        elif confidence < 0.35:
            reply = f"{text_for['low_confidence']} ({confidence:.0%}) {text_for['be_specific']}"
        else:
            for attempt in range(1, (GUARD_ATTEMPTS if temperature > 0 else 1) + 1):
                text, finished = generate(generator, gen_checkpoint['vocab'], question, answer_id, temperature)
                if guard_accepts(text, finished, answer_id, lang):
                    break
            info.update(generated=text, finished=finished, similarity=similarity(text, answer_id, lang), attempts=attempt)
            if guard_accepts(text, finished, answer_id, lang):
                info['source'] = 'generator'
                reply = f"{text} ({text_for['score']} {confidence:.0%})"
            else:
                info['source'] = 'fallback'
                reply = f"{kaprao.answer_text(cls_checkpoint, answer_id, lang)} ({text_for['score']} {confidence:.0%})"
    return (reply, info) if detail else reply


def report(temperature, samples):
    classifier, cls_checkpoint = kaprao.loaded_model()
    generator, gen_checkpoint = loaded_generator()
    data = kaprao.load_data()
    if gen_checkpoint['dataset_sha256'] != kaprao.fingerprint(data):
        raise ValueError('Dataset changed since the generator was trained. Run train-gen again.')
    fresh = json.loads((BASE / 'data' / 'fresh_test_questions.json').read_text(encoding='utf-8'))
    known_train = {v for lang in LANGUAGES for variants in TRAIN_VARIANTS[lang].values() for v in variants}
    known_held_out = {v for lang in LANGUAGES for variants in HELD_OUT[lang].values() for v in variants}
    rng = torch.Generator().manual_seed(0)
    result = {'generator_parameters': sum(p.numel() for p in generator.parameters()), 'generator_epoch': gen_checkpoint['epoch'], 'temperature': temperature, 'guard': f'exact match to a verified sentence; {GUARD_ATTEMPTS} attempts when sampling', 'splits': {}}
    new_fresh = json.loads((BASE / 'data' / 'new_topic_fresh_questions.json').read_text(encoding='utf-8'))
    for split, rows in (('validation', data['validation']), ('test', data['test']), ('fresh_test', fresh), ('new_topic_test', data['new_topic_test']), ('new_topic_fresh', new_fresh), ('en_test', data['en_test']),
                        ('en_fresh', json.loads((BASE / 'data' / 'en_fresh_questions.json').read_text(encoding='utf-8')))):
        known = [r for r in rows if r['answer_id'] in ANSWER_VARIANTS]
        # Generator alone, given the correct category.
        gen_rows = []
        for r in known:
            for _ in range(samples):
                text, finished = generate(generator, gen_checkpoint['vocab'], r['question'], r['answer_id'], temperature, rng)
                lang = kaprao.language(r['question'])
                gen_rows.append({'question': r['question'], 'answer_id': r['answer_id'], 'language': lang, 'generated': text, 'finished': finished, 'similarity': similarity(text, r['answer_id'], lang), 'copied_variant': text in known_train, 'new_valid_sentence': text in known_held_out})
        # Full hybrid pipeline: classifier category, generator text, guard.
        sources = {'generator': 0, 'fallback': 0, 'classifier': 0}
        correct_category = 0
        for r in known:
            _, info = ask(r['question'], classifier, cls_checkpoint, generator, gen_checkpoint, temperature, detail=True)
            sources[info['source']] += 1
            correct_category += info.get('answer_id') == r['answer_id']
        n = len(gen_rows)
        stats = {
            'questions': len(known),
            'generator_finished': sum(g['finished'] for g in gen_rows) / n,
            'generator_mean_similarity': sum(g['similarity'] for g in gen_rows) / n,
            'generator_passes_guard': sum(guard_accepts(g['generated'], g['finished'], g['answer_id'], g['language']) for g in gen_rows) / n,
            'generator_copied_a_training_paraphrase': sum(g['copied_variant'] for g in gen_rows) / n,
            # Valid sentence assembled from learned clauses but never seen whole in training.
            'generator_new_valid_sentence': sum(g['new_valid_sentence'] for g in gen_rows) / n,
            # Neither seen nor in the valid set; the guard decides whether it is shown.
            'generator_other_new_text': sum(not g['copied_variant'] and not g['new_valid_sentence'] for g in gen_rows) / n,
            'distinct_outputs_per_question': len({(g['question'], g['generated']) for g in gen_rows}) / max(1, len(known)),
            'hybrid_correct_category': correct_category / len(known),
            'hybrid_reply_sources': sources,
            'results': gen_rows,
        }
        result['splits'][split] = stats
        print(f"{split}: category {correct_category}/{len(known)}; generator finished {stats['generator_finished']:.1%}, "
              f"mean similarity {stats['generator_mean_similarity']:.2f}, passes guard {stats['generator_passes_guard']:.1%}, "
              f"copied {stats['generator_copied_a_training_paraphrase']:.1%}, new valid {stats['generator_new_valid_sentence']:.1%}, "
              f"other new {stats['generator_other_new_text']:.1%}, distinct/question {stats['distinct_outputs_per_question']:.2f}; replies {sources}")
    (BASE / 'hybrid_report.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Saved hybrid_report.json')


def main():
    import sys
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    torch.set_num_threads(min(4, torch.get_num_threads()))
    parser = argparse.ArgumentParser(description='KapraoTiny hybrid: classifier + tiny generator')
    sub = parser.add_subparsers(dest='command', required=True)
    tr = sub.add_parser('train-gen')
    tr.add_argument('--epochs', type=int, default=60)
    tr.add_argument('--batch-size', type=int, default=16)
    tr.add_argument('--lr', type=float, default=0.0005)
    tr.add_argument('--seed', type=int, default=42)
    ev = sub.add_parser('evaluate')
    ev.add_argument('--temperature', type=float, default=0.0)
    ev.add_argument('--samples', type=int, default=1)
    qa = sub.add_parser('ask')
    qa.add_argument('question', nargs='?')
    qa.add_argument('--temperature', type=float, default=0.0, help='0 = greedy; 0.7-1.0 = more varied wording')
    qa.add_argument('--debug', action='store_true', help='show the category, raw generated text and guard score')
    args = parser.parse_args()
    if args.command == 'train-gen':
        train(args)
    elif args.command == 'evaluate':
        report(args.temperature, max(1, args.samples))
    else:
        models = (*kaprao.loaded_model(), *loaded_generator())

        def answer(q):
            reply, info = ask(q, *models, args.temperature, detail=True)
            print('KapraoTiny:', reply)
            if args.debug:
                print('  ', {k: (round(v, 3) if isinstance(v, float) else v) for k, v in info.items()})

        if args.question is not None:
            answer(args.question)
        else:
            print('ถามเรื่องกะเพราได้เลย ภาษาไทยหรือ English (พิมพ์ exit เพื่อออก)')
            while True:
                try:
                    q = input('คุณ: ').strip()
                except (EOFError, KeyboardInterrupt):
                    break
                if q.lower() in {'exit', 'quit', 'ออก'}:
                    break
                if q:
                    answer(q)


if __name__ == '__main__':
    main()
