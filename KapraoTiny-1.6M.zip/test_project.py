"""Run with: python -m unittest -v test_project"""
import unittest
import json
from unittest.mock import Mock

import torch

import kaprao


class ProjectChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)
        cls.data = kaprao.load_data()
        cls.vocab = kaprao.load_vocab()

    def test_training_validation_and_test_are_disjoint(self):
        kaprao.audit_splits(self.data)

    def test_every_answer_has_examples_in_every_split(self):
        known = set(range(kaprao.UNKNOWN_ANSWER_ID))
        new_topics = set(range(kaprao.UNKNOWN_ANSWER_ID + 1, len(self.data['answers'])))
        for split in ('train', 'validation'):
            self.assertEqual({r['answer_id'] for r in self.data[split]}, known | new_topics | {kaprao.UNKNOWN_ANSWER_ID})
        for split in ('test', 'legacy_test'):
            self.assertEqual({r['answer_id'] for r in self.data[split]}, known)
        self.assertEqual({r['answer_id'] for r in self.data['new_topic_test']}, new_topics)
        self.assertEqual({r['answer_id'] for r in self.data['unsupported_test']}, {kaprao.UNKNOWN_ANSWER_ID})

    def test_vocabulary_uses_training_only(self):
        chars = {c for row in self.data['train'] for c in kaprao.tokenize(row['question'])}
        self.assertEqual(set(self.vocab) - set(kaprao.SPECIAL), chars)

    def test_model_matches_parameter_budget(self):
        model = kaprao.TinyTransformer(len(self.vocab), len(self.data['answers']), **kaprao.CONFIG)
        count = sum(p.numel() for p in model.parameters())
        self.assertGreaterEqual(count, 1_000_000)
        self.assertLessEqual(count, 2_000_000)

    def test_blank_and_unknown_inputs_have_finite_logits(self):
        model = kaprao.TinyTransformer(len(self.vocab), len(self.data['answers']), **kaprao.CONFIG).eval()
        inputs = torch.tensor([kaprao.encode('   ', self.vocab), kaprao.encode('😀xyz', self.vocab)])
        with torch.no_grad():
            logits = model(inputs)
        self.assertEqual(tuple(logits.shape), (2, len(self.data['answers'])))
        self.assertTrue(torch.isfinite(logits).all())

    def test_checkpoint_matches_current_dataset(self):
        model, checkpoint = kaprao.loaded_model()
        self.assertEqual(checkpoint['dataset_sha256'], kaprao.fingerprint(self.data))
        self.assertEqual(checkpoint['vocab'], self.vocab)
        self.assertEqual(model.max_len, kaprao.CONFIG['max_len'])


    def test_other_dishes_are_rejected_before_model_inference(self):
        model = Mock()
        model.max_len = 64
        questions = json.loads((kaprao.BASE / 'data' / 'out_of_scope_questions.json').read_text(encoding='utf-8'))
        for question in questions:
            with self.subTest(question=question):
                expected = 'greeting' if kaprao.is_greeting(question) else 'out_of_scope'
                self.assertEqual(kaprao.ask(question, model, {}), kaprao.messages(kaprao.language(question))[expected])
        model.assert_not_called()

    def test_all_held_out_kaprao_examples_still_pass_scope_check(self):
        fresh = json.loads((kaprao.BASE / 'data' / 'fresh_test_questions.json').read_text(encoding='utf-8'))
        for rows in [self.data[split] for split in ('validation', 'test', 'legacy_test', 'new_topic_test')] + [fresh]:
            for row in rows:
                with self.subTest(question=row['question']):
                    self.assertTrue(kaprao.is_in_scope(row['question']))

    def test_supported_spelling_and_comparison_still_receive_answers(self):
        model, checkpoint = kaprao.loaded_model()
        for question in ['ผัดกะเพราใส่อะไรบ้าง', 'ผัดกระเพราใส่อะไรบ้าง']:
            response = kaprao.ask(question, model, checkpoint)
            self.assertIn(checkpoint['answers'][1], response)
            self.assertNotIn('ความมั่นใจ', response)
        comparison = kaprao.ask('กะเพราต่างจากโหระพาอย่างไร', model, checkpoint)
        self.assertIn(checkpoint['answers'][4], comparison)

    def test_ambiguous_question_requires_explicit_domain(self):
        model = Mock()
        model.max_len = 64
        # This training phrase is ambiguous outside its original cooking context.
        self.assertEqual(kaprao.ask('ควรผัดพริกกระเทียมหรือเนื้อก่อน', model, {}), kaprao.OUT_OF_SCOPE_MESSAGE)
        self.assertTrue(kaprao.is_in_scope('ทำกะเพราควรผัดพริกกระเทียมหรือเนื้อก่อน'))
        model.assert_not_called()

    def test_blank_and_truncated_domain_name_do_not_trigger_inference(self):
        model = Mock()
        model.max_len = 64
        self.assertEqual(kaprao.ask('   ', model, {}), 'กรุณาพิมพ์คำถามเรื่องกะเพรา')
        # 65 separate tokens push the domain name past the 64-token window. (A run of English
        # letters is one token, so 'x' * 65 would be a single token.)
        self.assertEqual(kaprao.ask('x ' * 65 + 'กะเพรา', model, {}), kaprao.OUT_OF_SCOPE_MESSAGE)
        self.assertEqual(len(kaprao.tokenize('x ' * 65 + 'กะเพรา')), 66)
        model.assert_not_called()


    def test_history_is_answered_without_naming_an_inventor(self):
        model, checkpoint = kaprao.loaded_model()
        history = next(i for i, a in enumerate(checkpoint['answers']) if 'รัชกาลที่ 7' in a)
        for question in ['ใครเป็นคนคิดเมนูกระเพราคนแรก', 'ผัดกะเพราคนแรกของโลกเป็นใคร']:
            with self.subTest(question=question):
                self.assertIn(checkpoint['answers'][history], kaprao.ask(question, model, checkpoint))

    def test_medical_and_price_questions_are_still_refused(self):
        model, checkpoint = kaprao.loaded_model()
        for question in ['ใช้กะเพราทำยารักษามะเร็งได้ไหม', 'ข้าวกะเพราจานหนึ่งให้พลังงานกี่แคลอรี', 'ขอราคากะเพราหมูสับวันนี้']:
            with self.subTest(question=question):
                self.assertEqual(kaprao.ask(question, model, checkpoint), kaprao.UNKNOWN_MESSAGE)

    def test_english_questions_get_english_answers(self):
        model, checkpoint = kaprao.loaded_model()
        self.assertIn(checkpoint['answers_en'][1], kaprao.ask('What goes into pad kaprao?', model, checkpoint))
        self.assertIn('model score', kaprao.ask('What goes into pad kaprao?', model, checkpoint))
        self.assertEqual(kaprao.ask('Can holy basil cure cancer?', model, checkpoint), checkpoint['answers_en'][kaprao.UNKNOWN_ANSWER_ID])
        self.assertEqual(kaprao.ask('Tell me about pizza', model, checkpoint), kaprao.messages('en')['out_of_scope'])

    def test_thai_tokenization_ignores_spaces_but_english_words_stay_whole(self):
        self.assertEqual(kaprao.tokenize('ผัด กะเพรา ใส่ อะไร'), kaprao.tokenize('ผัดกะเพราใส่อะไร'))
        self.assertEqual(kaprao.tokenize('Holy  Basil?'), ['holy', 'basil', '?'])
        self.assertEqual(kaprao.language('What is holy basil?'), 'en')
        self.assertEqual(kaprao.language('holy basil คืออะไร'), 'th')

    def test_greetings_get_a_friendly_reply_in_the_same_language(self):
        model = Mock()
        model.max_len = 64
        for question, lang in [('hi', 'en'), ('Hello!', 'en'), ('good morning', 'en'), ('สวัสดีครับ', 'th'), ('หวัดดีค่ะ', 'th'), ('สวัสดี ครับผม!', 'th')]:
            with self.subTest(question=question):
                self.assertEqual(kaprao.ask(question, model, {}), kaprao.messages(lang)['greeting'])
        model.assert_not_called()
        # A greeting with a question is still a question.
        for question in ['hi kaprao', 'hello, what is holy basil?', 'สวัสดีครับ กะเพราคืออะไร', 'ดีมาก', 'ครับ']:
            with self.subTest(question=question):
                self.assertFalse(kaprao.is_greeting(question))
        # ...and the leading greeting is removed before the model sees it.
        self.assertEqual(kaprao.strip_greeting('สวัสดีครับ กะเพราคืออะไร'), 'กะเพราคืออะไร')
        self.assertEqual(kaprao.strip_greeting('สวัสดีครับกะเพราใส่อะไร'), 'กะเพราใส่อะไร')
        self.assertEqual(kaprao.strip_greeting('Hi! What goes into pad kaprao?'), 'What goes into pad kaprao?')
        self.assertEqual(kaprao.strip_greeting('hippo kaprao'), 'hippo kaprao')
        self.assertEqual(kaprao.strip_greeting('ดีมาก'), 'ดีมาก')

    def test_help_questions_list_what_the_model_covers(self):
        model = Mock()
        model.max_len = 64
        for question, lang in [('ทำอะไรได้บ้าง', 'th'), ('ถามอะไรได้บ้างครับ', 'th'), ('ทำ อะไร ได้ บ้าง?', 'th'),
                               ('สวัสดีครับ ทำอะไรได้บ้าง', 'th'), ('What can you do?', 'en'), ('HELP', 'en'), ('Hi, what can I ask?', 'en')]:
            with self.subTest(question=question):
                self.assertEqual(kaprao.ask(question, model, {}), kaprao.messages(lang)['help'])
        model.assert_not_called()
        # Kaprao questions that happen to contain the same words still go to the model.
        for question in ['กะเพราทำอะไรได้บ้าง', 'help me with kaprao']:
            with self.subTest(question=question):
                self.assertFalse(kaprao.is_help(question))

    def test_other_kaprao_dishes_are_in_scope(self):
        for question in ['ผัดขี้เมาใส่อะไรบ้าง', 'แกงป่าใส่กะทิไหม', 'โป๊ะแตกคืออะไร']:
            with self.subTest(question=question):
                self.assertTrue(kaprao.is_in_scope(question))

    def test_report_keeps_known_answers_and_unknown_rejection_separate(self):
        model, checkpoint = kaprao.loaded_model()
        stats = kaprao.evaluate(model, self.data['unsupported_test'], checkpoint['vocab'], 'cpu')
        self.assertGreaterEqual(stats['accuracy'], 0.8)
        known = kaprao.evaluate(model, self.data['legacy_test'], checkpoint['vocab'], 'cpu')
        self.assertGreaterEqual(known['accuracy'], 0.6)


if __name__ == '__main__':
    unittest.main()
