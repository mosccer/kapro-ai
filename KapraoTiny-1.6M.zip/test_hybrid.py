import json
import unittest

import torch

import kaprao
import kaprao_hybrid as hybrid


class HybridTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.models = (*kaprao.loaded_model(), *hybrid.loaded_generator())
        cls.data = kaprao.load_data()

    def test_variants_cover_every_known_answer(self):
        expected = set(range(len(self.data['answers']))) - {kaprao.UNKNOWN_ANSWER_ID}
        self.assertEqual(set(hybrid.ANSWER_VARIANTS), expected)
        for answer_id, variants in hybrid.ANSWER_VARIANTS.items():
            self.assertEqual(variants[0], self.data['answers'][answer_id])

    def test_generator_size_fits_board(self):
        params = sum(p.numel() for p in self.models[2].parameters())
        self.assertLess(params, 3_000_000)

    def test_generator_is_trained_on_current_dataset(self):
        self.assertEqual(self.models[3]['dataset_sha256'], kaprao.fingerprint(self.data))

    def test_generation_terminates_and_stays_on_topic(self):
        generator, checkpoint = self.models[2:]
        for answer_id in hybrid.CLASS_IDS:
            text, finished = hybrid.generate(generator, checkpoint['vocab'], 'กะเพราคืออะไร', answer_id)
            self.assertTrue(text)
            self.assertLessEqual(len(hybrid.gen_tokenize(text)), hybrid.MAX_ANSWER)

    def test_sampling_never_emits_special_tokens(self):
        generator, checkpoint = self.models[2:]
        rng = torch.Generator().manual_seed(1)
        for _ in range(5):
            text, _ = hybrid.generate(generator, checkpoint['vocab'], 'ผัดกะเพราใส่อะไรบ้าง', 1, 1.0, rng)
            self.assertNotIn('<', text)

    def test_refusals_never_reach_generator(self):
        cases = {
            'ผัดหมูกระเทียมใส่อะไรบ้าง': kaprao.OUT_OF_SCOPE_MESSAGE,
            '   ': 'กรุณาพิมพ์คำถามเรื่องกะเพรา',
        }
        for question, expected in cases.items():
            reply, info = hybrid.ask(question, *self.models, detail=True)
            self.assertEqual(reply, expected)
            self.assertEqual(info['source'], 'classifier')

    def test_english_question_gets_english_generated_answer(self):
        reply, info = hybrid.ask('What is jungle curry?', *self.models, detail=True)
        self.assertEqual(info['language'], 'en')
        self.assertIn(info['source'], ('generator', 'fallback'))
        self.assertIn('curry', reply)
        self.assertIn('model score', reply)

    def test_unknown_category_is_refused_by_classifier(self):
        reply, info = hybrid.ask('ใช้กะเพราทำยารักษามะเร็งได้ไหม', *self.models, detail=True)
        self.assertEqual(info['source'], 'classifier')
        self.assertEqual(reply, kaprao.UNKNOWN_MESSAGE)

    def test_guard_falls_back_to_fixed_answer(self):
        classifier, cls_checkpoint, generator, gen_checkpoint = self.models
        original = hybrid.generate
        hybrid.generate = lambda *args, **kwargs: ('ข้อความที่ไม่เกี่ยวข้องเลย', True)
        try:
            reply, info = hybrid.ask('ผัดกะเพราใส่อะไรบ้าง', *self.models, detail=True)
        finally:
            hybrid.generate = original
        self.assertEqual(info['source'], 'fallback')
        self.assertTrue(reply.startswith(cls_checkpoint['answers'][info['answer_id']]))


if __name__ == '__main__':
    unittest.main()
