import argparse
import hashlib
import json
import math
import random
import re
from pathlib import Path

import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset

BASE = Path(__file__).resolve().parent
SPECIAL = ['<pad>', '<unk>']
CONFIG = {'dim': 256, 'layers': 3, 'heads': 4, 'ffn': 512, 'max_len': 64}


LEXICON = sorted(['กะเพรา', 'โหระพา', 'หมูสับ', 'หมูบด', 'หมู', 'ไก่', 'ไข่ดาว', 'ไข่เจียว', 'ไข่', 'ส่วนผสม', 'ส่วนประกอบ', 'วัตถุดิบ', 'เครื่องปรุง', 'กระเทียม', 'ขั้นตอน', 'ลำดับ', 'เริ่ม', 'ผัด', 'ทำ', 'วิธี', 'พริก', 'เผ็ด', 'เด็ดยอด', 'เด็ด', 'แตกกิ่ง', 'แตกยอด', 'แตกใบ', 'ตัดแต่ง', 'ตัด', 'ยอด', 'กิ่ง', 'ตู้เย็น', 'แช่เย็น', 'เก็บรักษา', 'เก็บ', 'ความสด', 'สด', 'เหี่ยว', 'หอม', 'กลิ่น', 'ฉุน', 'หวาน', 'ทดแทน', 'แทน', 'ไม่มี', 'หมด', 'ล้าง', 'สะเด็ดน้ำ', 'สะอาด', 'แฉะ', 'เปียก', 'กระเด็น', 'แดง', 'ขาว', 'ม่วง', 'สี', 'เต้าหู้', 'โปรตีนเกษตร', 'โปรตีนพืช', 'โปรตีน', 'มังสวิรัติ', 'วีแกน', 'เจ', 'ดิน', 'แดด', 'ปลูก', 'ดูแล', 'รดน้ำ', 'น้ำขัง', 'ระบายน้ำ', 'กระทะ', 'ใส่', 'เติม', 'ปิดไฟ', 'ท้าย', 'สูตร', 'สับ', 'บด', 'เนื้อสัตว์', 'เนื้อ', 'พืช', 'สมุนไพร', 'วงศ์', 'คือ', 'อะไร', 'ได้ไหม', 'อย่างไร', 'ยังไง', 'ครับ', 'ค่ะ', 'ใบ', 'เครื่องเคียง', 'กิน', 'คู่', 'เตรียม', 'ต่าง', 'เหมือน', 'ชนิด', 'แบบ', 'อาหาร', 'เมนู', 'ข้อมูล', 'อธิบาย', 'ก่อน', 'หลัง'], key=lambda word: (-len(word), word))

LEXICON = sorted(set(LEXICON + ['ประวัติ', 'คิดค้น', 'คนแรก', 'ผู้คิดค้น', 'ต้นกำเนิด', 'พลังงาน', 'แคลอรี', 'รักษา', 'โรค', 'ราคา', 'ร้านไหน', 'จังหวัด', 'ประเทศ', 'คำนวณ', 'งานวิจัย', 'ผู้ริเริ่ม', 'สรรพคุณ', 'วิตามิน', 'กรัม', 'มิลลิกรัม']), key=lambda word: (-len(word), word))
# v2 terms for new topics and other dishes that use kaprao leaves.
LEXICON = sorted(set(LEXICON + ['ชื่อวิทยาศาสตร์', 'วิทยาศาสตร์', 'พฤกษศาสตร์', 'ภาษาอังกฤษ', 'ชื่อพ้อง', 'ท้องถิ่น', 'ลักษณะ', 'ลำต้น', 'ดอก', 'ไม้พุ่ม', 'ถิ่นกำเนิด', 'พื้นเมือง', 'อินเดีย', 'ฮินดู', 'ศักดิ์สิทธิ์', 'บูชา', 'ตุลสี', 'ตำรายา', 'ขับลม', 'ท้องอืด', 'ท้องเฟ้อ', 'น้ำมันหอมระเหย', 'ยูจีนอล', 'สารสำคัญ', 'ขยายพันธุ์', 'เพาะเมล็ด', 'เมล็ด', 'ปักชำ', 'เก็บเกี่ยว', 'ทะเล', 'กุ้ง', 'ปลาหมึก', 'ถั่วฝักยาว', 'หอมใหญ่', 'หมูกรอบ', 'ผัก', 'ยอดนิยม', 'นิยม', 'ขี้เมา', 'แกงป่า', 'กระชาย', 'กะทิ', 'พริกไทยอ่อน', 'มะเขือ', 'โป๊ะแตก', 'ต้มยำ', 'เส้น', 'แกง', 'ต้ม']), key=lambda word: (-len(word), word))
# Questions must name kaprao or one of the kaprao dishes in the knowledge base.
SCOPE_TERMS = {'กะเพรา', 'ขี้เมา', 'แกงป่า', 'โป๊ะแตก', 'ตุลสี'}
# English questions: common romanisations of kaprao plus the English dish and plant names.
SCOPE_TERMS |= {'kaprao', 'krapao', 'kraprao', 'kaphrao', 'krapow', 'kaprow', 'gaprao', 'gapow', 'kapow', 'pao', 'pow', 'prao',
                'basil', 'tulsi', 'ocimum', 'drunken', 'kee', 'mao', 'jungle', 'gaeng', 'taek'}
UNKNOWN_ANSWER_ID = 16
UNKNOWN_MESSAGE = "ยังไม่มีข้อมูลตอบคำถามนี้ โมเดลรองรับเรื่องส่วนผสม วิธีทำ และการดูแลกะเพรา"


ASCII_WORD = re.compile(r'[a-z]+')


def language(text):
    # English when the question has Latin letters and no Thai characters; otherwise Thai.
    return 'en' if re.search(r'[A-Za-z]', text) and not re.search('[\u0e00-\u0e7f]', text) else 'th'


def tokenize(text):
    text = text.strip().lower().replace('กระเพรา', 'กะเพรา')
    # Whitespace is dropped (Thai has no word spaces), except one space between two ASCII
    # letters/digits so English words stay apart. Thai-only text tokenizes as before.
    text = re.sub(r'\s+', lambda m: ' ' if 0 < m.start() and m.end() < len(text) and
                  re.match(r'[a-z0-9]', text[m.start() - 1]) and re.match(r'[a-z0-9]', text[m.end()]) else '', text)
    # English words are whole tokens; Thai uses longest-match terms with character fallback.
    tokens = []
    i = 0
    while i < len(text):
        if text[i] == ' ':
            i += 1
            continue
        word = ASCII_WORD.match(text, i)
        term = word.group() if word else next((w for w in LEXICON if text.startswith(w, i)), None) or text[i]
        tokens.append(term)
        i += len(term)
    return tokens


class TinyTransformer(nn.Module):
    def __init__(self, vocab_size, classes, dim=256, layers=3, heads=4, ffn=512, max_len=64):
        super().__init__()
        self.token = nn.Embedding(vocab_size, dim, padding_idx=0)
        self.position = nn.Embedding(max_len, dim)
        block = nn.TransformerEncoderLayer(dim, heads, ffn, dropout=0.1, batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(block, layers, norm=nn.LayerNorm(dim), enable_nested_tensor=False)
        self.classifier = nn.Linear(dim, classes)
        self.max_len = max_len
        # Each encoder layer receives independently initialized weights.
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
        for layer in self.encoder.layers:
            nn.init.xavier_uniform_(layer.self_attn.in_proj_weight)
        nn.init.normal_(self.token.weight, std=0.02)
        nn.init.normal_(self.position.weight, std=0.02)
        with torch.no_grad():
            self.token.weight[0].zero_()

    def forward(self, ids):
        length = int(ids.ne(0).sum(1).max().clamp_min(1))
        ids = ids[:, :length]
        mask = ids.eq(0)
        # Guard against all-padding inputs, including input containing only spaces.
        if mask.all(1).any():
            ids = ids.clone()
            ids[mask.all(1), 0] = 1
            mask = ids.eq(0)
        pos = torch.arange(ids.size(1), device=ids.device)
        x = self.token(ids) * math.sqrt(self.token.embedding_dim) + self.position(pos)[None]
        x = self.encoder(x, src_key_padding_mask=mask)
        pooled = x.masked_fill(mask.unsqueeze(-1), 0).sum(1) / (~mask).sum(1).clamp_min(1).unsqueeze(-1)
        return self.classifier(pooled)


def encode(text, vocab, max_len=64):
    ids = [vocab.get(ch, 1) for ch in tokenize(text)][:max_len]
    return ids + [0] * (max_len - len(ids))


class QAData(Dataset):
    def __init__(self, rows, vocab, augment=False):
        self.rows, self.vocab, self.augment = rows, vocab, augment

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, i):
        row = self.rows[i]
        text = row['question']
        if self.augment and random.random() < 0.5:
            text = random.choice(['', 'ช่วยบอกหน่อยว่า', 'อยากถามว่า', 'ขอถามหน่อย ']) + text
            text += random.choice(['', 'ครับ', 'ค่ะ', 'หน่อย'])
        return torch.tensor(encode(text, self.vocab)), row['answer_id']


def load_data():
    return json.loads((BASE / 'data' / 'dataset.json').read_text(encoding='utf-8'))


def question_key(text):
    return ''.join(tokenize(text))


def audit_splits(data):
    seen = {}
    for split in ('train', 'validation', 'test', 'legacy_test', 'fresh_test', 'new_topic_test', 'new_topic_fresh', 'v3_fresh', 'en_test', 'en_fresh', 'unsupported_test'):
        if split not in data:
            continue
        for row in data[split]:
            key = question_key(row['question'])
            if not key:
                raise ValueError('Empty question')
            if key in seen:
                raise ValueError(f'Duplicate question across splits: {seen[key]} / {split}: {row}')
            if not 0 <= row['answer_id'] < len(data['answers']):
                raise ValueError('Invalid answer ID')
            seen[key] = split


def make_dataset():
    from dataset_source import KNOWLEDGE
    from dataset_extra import EXTRA_TRAIN, VALIDATION
    original = json.loads((BASE / 'backup_v1' / 'data' / 'dataset.json').read_text(encoding='utf-8'))
    test = json.loads((BASE / 'data' / 'test_questions.json').read_text(encoding='utf-8'))
    val = [{'question': q, 'answer_id': i} for i, qs in enumerate(VALIDATION) for q in qs]
    legacy = original['test']
    reserved = {question_key(r['question']) for r in val + test + legacy}
    # The old source has two questions assigned conflicting labels. Remove both forms.
    ambiguous = {question_key(q) for q in ['เก็บใบกะเพราอย่างไร', 'ใช้โหระพาแทนกะเพราได้ไหม']}
    rows = []
    seen = {}
    for i, item in enumerate(KNOWLEDGE):
        for q in item['questions'] + EXTRA_TRAIN[i]:
            key = question_key(q)
            if key in reserved or key in ambiguous:
                continue
            if key in seen:
                if seen[key] != i:
                    raise ValueError(f'Conflicting training label: {q}')
                continue
            seen[key] = i
            rows.append({'question': q, 'answer_id': i})
    data = {'train': rows, 'validation': val, 'test': test, 'legacy_test': legacy, 'answers': [k['answer'] for k in KNOWLEDGE]}
    negatives = json.loads((BASE / 'data' / 'unsupported_questions.json').read_text(encoding='utf-8'))
    data['answers'].append(UNKNOWN_MESSAGE)
    data['unknown_answer_id'] = UNKNOWN_ANSWER_ID
    for split in ('train', 'validation'):
        data[split].extend({'question': q, 'answer_id': UNKNOWN_ANSWER_ID} for q in negatives[split])
    data['unsupported_test'] = [{'question': q, 'answer_id': UNKNOWN_ANSWER_ID} for q in negatives['test']]
    add_new_knowledge(data)
    add_english(data)
    audit_splits(data)
    # Fit vocabulary on training questions only.
    chars = sorted({c for r in data['train'] for c in tokenize(r['question'])})
    vocab = {s: i for i, s in enumerate(SPECIAL + chars)}
    out = BASE / 'data'
    (out / 'dataset.json').write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    (out / 'vocab.json').write_text(json.dumps(vocab, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Dataset:', {k: len(data[k]) for k in ('train', 'validation', 'test', 'legacy_test', 'new_topic_test', 'en_test', 'unsupported_test')}, f'; {len(data["answers"])} answers; {len(vocab)} tokens')


def add_new_knowledge(data):
    # v2 categories get IDs after the refusal class. Questions that used to be refused but
    # are now answerable move from the refusal sets to their new category in the same split.
    from dataset_v2 import EXTRA_NEGATIVES_TRAIN, NEW_KNOWLEDGE
    from dataset_v3 import EXTRA_TRAIN_V3, NEGATIVES_V3
    data['train'].extend({'question': q, 'answer_id': UNKNOWN_ANSWER_ID} for q in EXTRA_NEGATIVES_TRAIN + NEGATIVES_V3)
    data['new_topic_test'] = []
    split_names = {'train': 'train', 'validation': 'validation', 'test': 'unsupported_test'}
    for offset, item in enumerate(NEW_KNOWLEDGE):
        answer_id = len(data['answers'])
        data['answers'].append(item['variants'][0])
        for source, questions in item['relabel'].items():
            moved = {question_key(q) for q in questions}
            split = split_names[source]
            before = len(data[split])
            data[split] = [r for r in data[split] if not (r['answer_id'] == UNKNOWN_ANSWER_ID and question_key(r['question']) in moved)]
            if before - len(data[split]) != len(moved):
                raise ValueError(f"Relabel list for {item['key']} does not match the refusal set")
            target = 'new_topic_test' if source == 'test' else source
            data[target].extend({'question': q, 'answer_id': answer_id} for q in questions)
        data['train'].extend({'question': q, 'answer_id': answer_id} for q in item['train'])
        data['validation'].extend({'question': q, 'answer_id': answer_id} for q in item['validation'])
        data['new_topic_test'].extend({'question': q, 'answer_id': answer_id} for q in item['test'])
    data['train'].extend({'question': q, 'answer_id': i} for i, questions in EXTRA_TRAIN_V3.items() for q in questions)


def add_english(data):
    from dataset_en import ANSWERS_EN, EN_QUESTIONS
    if len(ANSWERS_EN) != len(data['answers']):
        raise ValueError('ANSWERS_EN must have one answer per answer ID')
    data['answers_en'] = ANSWERS_EN
    data['en_test'] = []
    for answer_id, splits in EN_QUESTIONS.items():
        for split, target in (('train', 'train'), ('validation', 'validation'), ('test', 'en_test')):
            data[target].extend({'question': q, 'answer_id': answer_id} for q in splits[split])
    from dataset_en_extra import EN_EXTRA_TRAIN
    from dataset_en_extra2 import EN_EXTRA_TRAIN_2
    for extra in (EN_EXTRA_TRAIN, EN_EXTRA_TRAIN_2):
        data['train'].extend({'question': q, 'answer_id': i} for i, questions in extra.items() for q in questions)


def load_vocab():
    return json.loads((BASE / 'data' / 'vocab.json').read_text(encoding='utf-8'))


def evaluate(model, rows, vocab, device):
    model.eval()
    results = []
    total_loss = 0.0
    with torch.no_grad():
        for ids, labels in DataLoader(QAData(rows, vocab), batch_size=32):
            logits = model(ids.to(device))
            total_loss += nn.functional.cross_entropy(logits, labels.to(device), reduction='sum').item()
            confidence, pred = logits.softmax(1).max(1)
            for label, guess, score in zip(labels.tolist(), pred.cpu().tolist(), confidence.cpu().tolist()):
                row = rows[len(results)]
                results.append({**row, 'predicted_id': guess, 'correct': guess == label, 'confidence': score, 'answered': score >= 0.35 and guess != UNKNOWN_ANSWER_ID, 'rejected_as_unknown': guess == UNKNOWN_ANSWER_ID})
    correct = sum(r['correct'] for r in results)
    return {'accuracy': correct / len(rows), 'correct': correct, 'total': len(rows), 'loss': total_loss / len(rows), 'answered_correct': sum(r['correct'] and r['answered'] for r in results), 'correct_unknown_rejections': sum(r['correct'] and r['rejected_as_unknown'] for r in results), 'results': results}


def fingerprint(data):
    return hashlib.sha256(json.dumps(data, ensure_ascii=False, sort_keys=True).encode('utf-8')).hexdigest()


def train(args):
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.set_num_threads(min(4, torch.get_num_threads()))
    data, vocab = load_data(), load_vocab()
    audit_splits(data)
    device = torch.device('cuda' if torch.cuda.is_available() and not args.cpu else 'cpu')
    model = TinyTransformer(len(vocab), len(data['answers']), **CONFIG).to(device)
    if args.init_from:
        previous = torch.load(args.init_from, map_location='cpu', weights_only=True)
        if previous['config'] != CONFIG or previous['answers'] != data['answers'][:len(previous['answers'])]:
            raise ValueError('Warm-start checkpoint configuration/answer IDs differ')
        current = model.state_dict()
        for name, tensor in previous['model'].items():
            if name == 'token.weight':
                for token, old_id in previous['vocab'].items():
                    if token in vocab:
                        current[name][vocab[token]].copy_(tensor[old_id])
            elif name.startswith('classifier.'):
                current[name][:tensor.shape[0]].copy_(tensor)
            else:
                current[name].copy_(tensor)
        model.load_state_dict(current)
        print('Initialized from previous checkpoint; added unknown-answer class.', flush=True)
    print(f'Parameters: {sum(p.numel() for p in model.parameters()):,}; device: {device}', flush=True)
    loader = DataLoader(QAData(data['train'], vocab, augment=True), batch_size=args.batch_size, shuffle=True)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.01)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=args.lr * 0.1)
    best_accuracy, best_loss, best_epoch = -1.0, float('inf'), 0
    history = []
    for epoch in range(1, args.epochs + 1):
        model.train()
        total = 0.0
        for ids, labels in loader:
            ids, labels = ids.to(device), labels.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss = nn.functional.cross_entropy(model(ids), labels, label_smoothing=0.05)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            total += loss.item()
        stats = evaluate(model, data['validation'], vocab, device)
        accuracy, val_loss = stats['accuracy'], stats['loss']
        history.append({'epoch': epoch, 'train_loss': total / len(loader), 'validation_accuracy': accuracy, 'validation_loss': val_loss})
        print(f'Epoch {epoch}: loss={total / len(loader):.4f}, validation_accuracy={accuracy:.1%}', flush=True)
        if accuracy > best_accuracy or (accuracy == best_accuracy and val_loss < best_loss):
            best_accuracy, best_loss, best_epoch = accuracy, val_loss, epoch
            torch.save({'model': model.state_dict(), 'config': CONFIG, 'vocab': vocab, 'answers': data['answers'], 'answers_en': data['answers_en'], 'validation_accuracy': accuracy, 'epoch': epoch, 'seed': args.seed, 'tokenizer_version': 'thai-terms-v5-en', 'unknown_answer_id': data['unknown_answer_id'], 'dataset_sha256': fingerprint(data)}, BASE / 'kaprao_model.pt')
        scheduler.step()
    (BASE / 'training_history.json').write_text(json.dumps(history, indent=2), encoding='utf-8')
    print(f'Saved kaprao_model.pt from epoch {best_epoch}; validation accuracy={best_accuracy:.1%}', flush=True)


def loaded_model():
    checkpoint = torch.load(BASE / 'kaprao_model.pt', map_location='cpu', weights_only=True)
    model = TinyTransformer(len(checkpoint['vocab']), len(checkpoint['answers']), **checkpoint['config'])
    model.load_state_dict(checkpoint['model'])
    model.eval()
    return model, checkpoint


OUT_OF_SCOPE_MESSAGE = 'คำถามนี้อยู่นอกขอบเขต ตอนนี้ตอบได้เฉพาะเรื่องกะเพรา'


# A message that is only a greeting gets a friendly reply instead of the out-of-scope message.
GREETINGS = {'hi', 'hello', 'hey', 'hiya', 'howdy', 'greetings', 'yo', 'hi there', 'hello there', 'hey there',
             'good morning', 'good afternoon', 'good evening', 'สวัสดี', 'หวัดดี', 'ดี', 'ดีจ้า', 'สวัสดีตอนเช้า', 'อรุณสวัสดิ์'}
# Polite endings dropped before matching, longest first.
GREETING_PARTICLES = sorted(['ครับผม', 'ครับ', 'คับ', 'ค่ะ', 'คะ', 'ค่า', 'ฮะ', 'จ้า', 'จ้ะ', 'จ๊ะ', 'นะ'], key=lambda p: (-len(p), p))
GREETING_PUNCTUATION = '!?.,~'


def greeting_key(text):
    text = ''.join(' ' if c.isspace() or c in GREETING_PUNCTUATION else c for c in text.lower())
    text = ' '.join(text.split())
    stripped = True
    while stripped:
        stripped = False
        for particle in GREETING_PARTICLES:
            if text.endswith(particle) and len(text) > len(particle):
                text, stripped = text[:-len(particle)].rstrip(), True
                break
    return text


def is_greeting(question):
    return greeting_key(question) in GREETINGS


# "What can you do?"-style questions get a help reply listing what the model covers.
# Thai phrases are stored without spaces and matched with the spaces removed.
HELP_PHRASES = {'help', 'help me', 'menu', 'what can you do', 'what can i ask', 'what can i ask you', 'what do you know',
                'what can you answer', 'what questions can i ask', 'what topics do you cover', 'who are you', 'what are you',
                'how do i use this', 'how does this work',
                'ช่วยด้วย', 'วิธีใช้', 'ใช้ยังไง', 'ใช้อย่างไร', 'ทำอะไรได้บ้าง', 'ทำอะไรได้', 'คุณทำอะไรได้บ้าง', 'ถามอะไรได้บ้าง',
                'ถามอะไรได้', 'ถามเรื่องอะไรได้บ้าง', 'ตอบอะไรได้บ้าง', 'ช่วยอะไรได้บ้าง', 'รู้อะไรบ้าง', 'คุณรู้อะไรบ้าง',
                'มีอะไรให้ถามบ้าง', 'คุณคือใคร', 'นี่คืออะไร'}


def is_help(question):
    key = greeting_key(question)
    return key in HELP_PHRASES or key.replace(' ', '') in HELP_PHRASES


# Greetings removed from the start of a longer question ('ดี' alone is too short to remove safely).
GREETING_PREFIXES = sorted(GREETINGS - {'ดี'}, key=lambda g: (-len(g), g))


def strip_greeting(question):
    # "สวัสดีครับ กะเพราคืออะไร" -> "กะเพราคืออะไร"; "hi, what is kaprao?" -> "what is kaprao?".
    # The models never saw greetings in training, so a leading one is removed before classifying.
    text = question.lstrip()
    for greeting in GREETING_PREFIXES:
        if text[:len(greeting)].lower() != greeting:
            continue
        rest = text[len(greeting):]
        if greeting.isascii() and rest[:1].isascii() and rest[:1].isalnum():
            continue  # "hippo" does not start with "hi"
        while True:
            rest = rest.lstrip()
            particle = next((p for p in GREETING_PARTICLES if rest.startswith(p)), None)
            if not particle:
                break
            rest = rest[len(particle):]
        rest = rest.lstrip(''.join(c for c in GREETING_PUNCTUATION) + ' ').lstrip()
        while rest[:1] and (rest[0].isspace() or rest[0] in GREETING_PUNCTUATION):
            rest = rest[1:]
        if rest:
            return rest
    return question


def is_in_scope(question, max_len=64):
    # Explicit application scope check, not a learned out-of-distribution detector.
    # Check the tokens actually visible to the model, including normalized spelling.
    return any(term in SCOPE_TERMS for term in tokenize(question)[:max_len])


MESSAGES = {
    'th': {'out_of_scope': OUT_OF_SCOPE_MESSAGE, 'empty': 'กรุณาพิมพ์คำถามเรื่องกะเพรา',
           'low_confidence': 'ยังไม่มั่นใจคำตอบ', 'be_specific': 'ลองถามเรื่องกะเพราให้เจาะจงขึ้น', 'score': 'คะแนนโมเดล',
           'greeting': 'สวัสดีครับ ถามเรื่องกะเพราได้เลย เช่น ส่วนผสม วิธีทำ การปลูก หรือเมนูที่ใช้ใบกะเพรา',
           'help': ('ถามเรื่องกะเพราได้ทั้งภาษาไทยและภาษาอังกฤษ เช่น ส่วนผสมและวิธีทำผัดกะเพรา การปลูกและดูแลต้นกะเพรา '
                    'ความต่างกับโหระพา ชื่อวิทยาศาสตร์ ประวัติผัดกะเพรา และเมนูอื่นที่ใช้ใบกะเพราอย่างผัดขี้เมา แกงป่า โป๊ะแตก '
                    'ลองถามว่า "ผัดกะเพราใส่อะไรบ้าง"')},
    'en': {'score': 'model score'},
}


def messages(lang):
    if lang == 'en' and 'out_of_scope' not in MESSAGES['en']:
        from dataset_en import MESSAGES_EN
        MESSAGES['en'].update(MESSAGES_EN)
    return MESSAGES[lang]


def answer_text(checkpoint, answer_id, lang):
    return (checkpoint.get('answers_en') or checkpoint['answers'])[answer_id] if lang == 'en' else checkpoint['answers'][answer_id]


def ask(question, model, checkpoint):
    if is_greeting(question):
        return messages(language(question))['greeting']
    question = strip_greeting(question)
    lang, text = language(question), messages(language(question))
    if is_help(question):
        return text['help']
    if not tokenize(question):
        return text['empty']
    if not is_in_scope(question, model.max_len):
        return text['out_of_scope']
    ids = torch.tensor([encode(question, checkpoint['vocab'], model.max_len)])
    with torch.no_grad():
        scores = model(ids).softmax(1)[0]
    confidence, index = scores.max(0)
    if index.item() == checkpoint.get('unknown_answer_id'):
        return answer_text(checkpoint, index.item(), lang)
    if confidence.item() < 0.35:
        return f"{text['low_confidence']} ({confidence.item():.0%}) {text['be_specific']}"
    return f"{answer_text(checkpoint, index.item(), lang)} ({text['score']} {confidence.item():.0%})"


def report_evaluation(details=False):
    model, checkpoint = loaded_model()
    data = load_data()
    audit_splits(data)
    if checkpoint['dataset_sha256'] != fingerprint(data):
        raise ValueError('Dataset changed since training. Train again before comparing scores.')
    report = {'parameters': sum(p.numel() for p in model.parameters()), 'selected_epoch': checkpoint['epoch'], 'dataset_sha256': checkpoint['dataset_sha256'], 'selection': 'validation accuracy; ties broken by validation loss', 'splits': {}}
    evaluation_data = {**data, 'fresh_test': json.loads((BASE / 'data' / 'fresh_test_questions.json').read_text(encoding='utf-8')),
                       'new_topic_fresh': json.loads((BASE / 'data' / 'new_topic_fresh_questions.json').read_text(encoding='utf-8')),
                       'v3_fresh': json.loads((BASE / 'data' / 'v3_fresh_questions.json').read_text(encoding='utf-8')),
                       'en_fresh': json.loads((BASE / 'data' / 'en_fresh_questions.json').read_text(encoding='utf-8'))}
    audit_splits(evaluation_data)
    report['fresh_test_sha256'] = fingerprint(evaluation_data['fresh_test'])
    for split in ('validation', 'test', 'legacy_test', 'fresh_test', 'new_topic_test', 'new_topic_fresh', 'v3_fresh', 'en_test', 'en_fresh', 'unsupported_test'):
        stats = evaluate(model, evaluation_data[split], checkpoint['vocab'], 'cpu')
        report['splits'][split] = stats
        if split == 'unsupported_test':
            print(f"Unsupported questions rejected correctly: {stats['correct_unknown_rejections']}/{stats['total']} ({stats['accuracy']:.1%})")
        else:
            print(f"{split}: {stats['accuracy']:.1%} ({stats['correct']}/{stats['total']}); correct above confidence threshold: {stats['answered_correct']}/{stats['total']}")
        if details:
            for row in stats['results']:
                print(f"{'OK' if row['correct'] else 'WRONG'} expected={row['answer_id']} predicted={row['predicted_id']}: {row['question']}")
    scope_questions = json.loads((BASE / 'data' / 'out_of_scope_questions.json').read_text(encoding='utf-8'))
    scope_results = []
    for question in scope_questions:
        response = ask(question, model, checkpoint)
        scope_results.append({'question': question, 'response': response, 'rejected': response == messages(language(question))['out_of_scope']})
    rejected = sum(row['rejected'] for row in scope_results)
    report['scope_check'] = {'kind': 'explicit kaprao term check; not learned OOD detection', 'rejected': rejected, 'total': len(scope_results), 'results': scope_results}
    print(f'Out-of-scope examples rejected: {rejected}/{len(scope_results)}')
    (BASE / 'evaluation_report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Saved evaluation_report.json')


def main():
    # Keep inference responsive on CPUs with many logical cores.
    torch.set_num_threads(min(4, torch.get_num_threads()))
    parser = argparse.ArgumentParser(description='KapraoTiny Thai question answering')
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('make-dataset')
    tr = sub.add_parser('train')
    tr.add_argument('--epochs', type=int, default=30)
    tr.add_argument('--batch-size', type=int, default=16)
    tr.add_argument('--lr', type=float, default=0.0003)
    tr.add_argument('--seed', type=int, default=42)
    tr.add_argument('--cpu', action='store_true')
    tr.add_argument('--init-from', type=Path, help='Optional previous checkpoint for warm-start training')
    ev = sub.add_parser('evaluate')
    ev.add_argument('--details', action='store_true')
    qa = sub.add_parser('ask')
    qa.add_argument('question', nargs='?')
    args = parser.parse_args()
    if args.command == 'make-dataset':
        make_dataset()
    elif args.command == 'train':
        if args.epochs < 1 or args.batch_size < 1 or args.lr <= 0:
            parser.error('epochs, batch-size and lr must be positive')
        train(args)
    elif args.command == 'evaluate':
        report_evaluation(args.details)
    else:
        model, checkpoint = loaded_model()
        if args.question is not None:
            print(ask(args.question, model, checkpoint))
        else:
            print('ถามเรื่องกะเพราได้เลย (พิมพ์ exit เพื่อออก)')
            while True:
                try:
                    q = input('คุณ: ').strip()
                except (EOFError, KeyboardInterrupt):
                    break
                if q.lower() in {'exit', 'quit', 'ออก'}:
                    break
                if q:
                    print('KapraoTiny:', ask(q, model, checkpoint))


if __name__ == '__main__':
    main()
