"""Check the AX7010 delivery package on the PC and rebuild SHA256SUMS + zip.

Run from anywhere:  python check_package.py [--skip-dry-run]

This verifies files, hashes, ARM ELF headers and the Windows C++ runner.
It cannot prove anything about the real board: NEON parity, Cortex-A9
execution, speed and memory must still be measured with board_test.sh on
the AX7010.
"""
import argparse
import hashlib
import json
import os
import platform
import shutil
import struct
import subprocess
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ZIP_PATH = HERE / 'AX7010_CPU_READY.zip'
REPORT_PATH = HERE / 'PACKAGE_CHECK.json'
ZIP_ROOT = 'ax7010_cpu'
EXCLUDE_NAMES = {'AX7010_CPU_READY.zip', 'SHA256SUMS', 'PACKAGE_CHECK.json', 'board_test_result.txt'}
EXCLUDE_DIRS = {'__pycache__'}
REQUIRED = [
    'bin/kaprao_ax7010', 'bin/kaprao_ax7010_scalar', 'bin/kaprao_cpu.exe',
    'model/kaprao_fp32.bin', 'model/kaprao_fp32.json', 'model/kaprao_gen_fp32.bin', 'model/kaprao_gen_fp32.json',
    'tests/reference.bin', 'tests/reference.json', 'tests/reference_manifest.json',
    'tests/gen_reference.bin', 'tests/gen_reference.json',
    'tests/board_questions.tsv', 'board_test.sh', 'self_test.sh', 'README_AX7010.md',
]
LF_ONLY = ['board_test.sh', 'self_test.sh', 'tests/board_questions.tsv', 'Makefile']
EXECUTABLE = {'bin/kaprao_ax7010', 'bin/kaprao_ax7010_scalar', 'board_test.sh', 'self_test.sh'}
ARM_BINARIES = ['bin/kaprao_ax7010', 'bin/kaprao_ax7010_scalar']


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def package_files():
    files = []
    for path in HERE.rglob('*'):
        rel = path.relative_to(HERE)
        if path.is_file() and path.name not in EXCLUDE_NAMES and not EXCLUDE_DIRS & set(rel.parts) \
                and not path.name.startswith('.board_test_'):
            files.append(rel.as_posix())
    return sorted(files, key=str.lower)


def check_elf(path):
    data = path.read_bytes()
    if data[:4] != b'\x7fELF':
        return {'ok': False, 'error': 'not ELF'}
    elf32, little = data[4] == 1, data[5] == 1
    machine, = struct.unpack_from('<H', data, 18)
    phoff, = struct.unpack_from('<I', data, 28)
    flags, = struct.unpack_from('<I', data, 36)
    phentsize, phnum = struct.unpack_from('<HH', data, 42)
    has_interp = any(struct.unpack_from('<I', data, phoff + i * phentsize)[0] == 3 for i in range(phnum))
    result = {
        'elf32': elf32, 'little_endian': little, 'machine_arm': machine == 40,
        'eabi_version': flags >> 24, 'hard_float': bool(flags & 0x400), 'static_no_interp': not has_interp,
    }
    result['ok'] = elf32 and little and machine == 40 and flags >> 24 == 5 and bool(flags & 0x400) and not has_interp
    return result


def find_bash():
    for candidate in [r'C:\Program Files\Git\bin\bash.exe', r'C:\Program Files (x86)\Git\bin\bash.exe']:
        if os.path.exists(candidate):
            return candidate
    found = shutil.which('bash')
    # System32\bash.exe is WSL, which cannot run the Windows .exe with this layout.
    return found if found and 'system32' not in found.lower() else None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--skip-dry-run', action='store_true', help='do not run board_test.sh with the Windows exe')
    args = parser.parse_args()
    checks, report = [], {'host': platform.platform(), 'physical_ax7010_tested': False}

    def record(name, ok, detail=''):
        checks.append({'check': name, 'ok': bool(ok), 'detail': detail})
        print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f' - {detail}' if detail else ''))

    for rel in REQUIRED:
        p = HERE / rel
        record(f'file {rel}', p.is_file() and p.stat().st_size > 0)
    for rel in LF_ONLY:
        p = HERE / rel
        record(f'LF line endings {rel}', p.is_file() and b'\r' not in p.read_bytes())
    for rel in ['board_test.sh', 'self_test.sh']:
        record(f'shebang {rel}', (HERE / rel).read_bytes().startswith(b'#!/bin/sh\n'))

    model_meta = json.loads((HERE / 'model/kaprao_fp32.json').read_text(encoding='utf-8'))
    ref_meta = json.loads((HERE / 'tests/reference_manifest.json').read_text(encoding='utf-8'))
    model_hash, ref_hash = sha256(HERE / 'model/kaprao_fp32.bin'), sha256(HERE / 'tests/reference.bin')
    record('model sha256 matches kaprao_fp32.json', model_hash == model_meta['sha256'], model_hash)
    record('model size matches kaprao_fp32.json', (HERE / 'model/kaprao_fp32.bin').stat().st_size == model_meta['bytes'])
    record('reference sha256 matches manifest', ref_hash == ref_meta['reference_sha256'], ref_hash)
    record('model and reference come from same checkpoint', model_meta['checkpoint_sha256'] == ref_meta['checkpoint_sha256'])
    checkpoint = HERE.parent / 'kaprao_model.pt'
    if checkpoint.exists():
        record('checkpoint ../kaprao_model.pt matches export', sha256(checkpoint) == model_meta['checkpoint_sha256'])
    gen_meta = json.loads((HERE / 'model/kaprao_gen_fp32.json').read_text(encoding='utf-8'))
    record('generator sha256 matches kaprao_gen_fp32.json', sha256(HERE / 'model/kaprao_gen_fp32.bin') == gen_meta['sha256'])
    record('generator and classifier trained on the same dataset', gen_meta['dataset_sha256'] == json.loads(
        (HERE / 'model/kaprao_fp32.json').read_text(encoding='utf-8'))['dataset_sha256'])
    gen_checkpoint = HERE.parent / 'kaprao_gen.pt'
    if gen_checkpoint.exists():
        record('checkpoint ../kaprao_gen.pt matches export', sha256(gen_checkpoint) == gen_meta['checkpoint_sha256'])

    manifest = json.loads((HERE / 'BUILD_MANIFEST.json').read_text(encoding='utf-8'))
    report['elf'] = {}
    for rel in ARM_BINARIES:
        elf = check_elf(HERE / rel)
        report['elf'][rel] = elf
        record(f'ARM ELF32 EABI5 hard-float static {rel}', elf['ok'])
        record(f'{rel} sha256 matches BUILD_MANIFEST', sha256(HERE / rel) == manifest['binaries'][Path(rel).name]['sha256'])

    cases = json.loads((HERE / 'tests/reference.json').read_text(encoding='utf-8'))
    # The same question can appear in several splits (raw_numerics bypasses the scope check), so accept any normal case.
    expected = {(c['question'], c['status'], str(c['answer_id'])) for c in cases if c['split'] != 'raw_numerics'}
    rows = [line.split('\t') for line in (HERE / 'tests/board_questions.tsv').read_text(encoding='utf-8').splitlines()
            if line and not line.startswith('#')]
    mismatched = [r[0] for r in rows if len(r) != 5 or (r[4], r[2], r[3]) not in expected]
    record(f'board_questions.tsv matches Python reference ({len(rows)} questions)', rows and not mismatched, ','.join(mismatched))

    # SHA256SUMS: LF only, every packaged file listed.
    files = package_files()
    sums = ''.join(f'{sha256(HERE / rel)}  {rel}\n' for rel in files)
    (HERE / 'SHA256SUMS').write_bytes(sums.encode('utf-8'))
    listed = [line.split('  ', 1) for line in (HERE / 'SHA256SUMS').read_text(encoding='utf-8').splitlines()]
    bad = [rel for digest, rel in listed if sha256(HERE / rel) != digest]
    record(f'SHA256SUMS rebuilt with LF and verified ({len(listed)} files)', not bad and b'\r' not in (HERE / 'SHA256SUMS').read_bytes(), ','.join(bad))

    exe = HERE / 'bin/kaprao_cpu.exe'
    if os.name == 'nt':
        r = subprocess.run([str(exe), '--model', 'model/kaprao_fp32.bin', '--self-test', 'tests/reference.bin'],
                           cwd=HERE, capture_output=True, text=True, encoding='utf-8')
        out = r.stdout.strip()
        report['windows_self_test'] = json.loads(out) if out.startswith('{') else out
        ok = isinstance(report['windows_self_test'], dict) and report['windows_self_test']['passed'] == report['windows_self_test']['total'] == len(cases)
        record('Windows C++ self-test vs Python', r.returncode == 0 and ok, out)
        r = subprocess.run([str(exe), '--model', 'model/kaprao_fp32.bin', '--gen', 'model/kaprao_gen_fp32.bin',
                            '--gen-self-test', 'tests/gen_reference.bin'], cwd=HERE, capture_output=True, text=True, encoding='utf-8')
        out = r.stdout.strip()
        report['windows_generator_self_test'] = json.loads(out) if out.startswith('{') else out
        gen_cases = len(json.loads((HERE / 'tests/gen_reference.json').read_text(encoding='utf-8')))
        ok = isinstance(report['windows_generator_self_test'], dict) and report['windows_generator_self_test']['generator_passed'] == gen_cases
        record('Windows C++ generator self-test vs Python', r.returncode == 0 and ok, out + r.stderr.strip()[:500])
    if not args.skip_dry_run:
        bash = find_bash()
        if bash and os.name == 'nt':
            env = dict(os.environ, KAPRAO_BIN='bin/kaprao_cpu.exe')
            r = subprocess.run([bash, 'board_test.sh'], cwd=HERE, env=env, capture_output=True, text=True, encoding='utf-8')
            summary = [l for l in r.stdout.splitlines() if l.startswith(('[FAIL]', '=== Summary', 'Inference only', 'Hybrid inference'))]
            report['board_test_dry_run_on_pc'] = {'exit_code': r.returncode, 'summary': summary}
            record('board_test.sh dry run on PC with Windows exe', r.returncode == 0, ' | '.join(summary))
        else:
            record('board_test.sh dry run on PC', False, 'Git Bash not found (use --skip-dry-run)')

    # Zip: Unix permissions so bin/* and *.sh stay executable after unzip on Linux.
    tmp = ZIP_PATH.with_suffix('.tmp')
    with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as z:
        for rel in files + ['SHA256SUMS']:
            info = zipfile.ZipInfo(f'{ZIP_ROOT}/{rel}', date_time=(2026, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (0o100755 if rel in EXECUTABLE else 0o100644) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, (HERE / rel).read_bytes())
    tmp.replace(ZIP_PATH)
    with zipfile.ZipFile(ZIP_PATH) as z:
        names = z.namelist()
        diff = [n for n in names if z.read(n) != (HERE / n[len(ZIP_ROOT) + 1:]).read_bytes()]
        perms_ok = all((z.getinfo(f'{ZIP_ROOT}/{rel}').external_attr >> 16) & 0o111 for rel in EXECUTABLE)
        record(f'zip rebuilt and matches disk ({len(names)} files)', not diff and z.testzip() is None, ','.join(diff))
        record('zip keeps 0755 on bin/* and *.sh', perms_ok)
    report['zip'] = {'path': ZIP_PATH.name, 'bytes': ZIP_PATH.stat().st_size, 'sha256': sha256(ZIP_PATH), 'files': len(names)}

    report['checks'] = checks
    report['passed'] = sum(c['ok'] for c in checks)
    report['total'] = len(checks)
    report['not_verified_without_board'] = [
        'ARM binary execution on Cortex-A9 / AX7010 Linux',
        'NEON numerical parity (classifier and generator self-tests of bin/kaprao_ax7010 on the board)',
        'Inference speed and memory use on AX7010',
        'UTF-8 Thai display over the board serial terminal',
    ]
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(f"\n{report['passed']}/{report['total']} PC checks passed. zip sha256 {report['zip']['sha256']}")
    print('Board itself NOT tested: run "sh board_test.sh" on the AX7010.')
    return 0 if report['passed'] == report['total'] else 1


if __name__ == '__main__':
    sys.exit(main())
