#!/bin/sh
# KapraoTiny board test for ALINX AX7010 (ARMv7 Linux). POSIX sh / BusyBox.
# Usage:  sh board_test.sh [--quick]
#   --quick  skip the self-tests and the benchmark
# Env:    KAPRAO_BIN=path  use another executable (e.g. bin/kaprao_cpu.exe for a PC dry run)
#         BENCH_RUNS=N     benchmark runs (default 20)
# Result: board_test_result.txt in this folder; exit code 0 only when every check passes.

cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)" || exit 1

QUICK=0
for arg in "$@"; do
    case "$arg" in
        --quick) QUICK=1 ;;
        -h|--help) sed -n '2,7p' "$0"; exit 0 ;;
        *) echo "Unknown option: $arg" >&2; exit 2 ;;
    esac
done

BIN=${KAPRAO_BIN:-bin/kaprao_ax7010}
SCALAR=bin/kaprao_ax7010_scalar
MODEL=model/kaprao_fp32.bin
GEN=model/kaprao_gen_fp32.bin
REFERENCE=tests/reference.bin
GEN_REFERENCE=tests/gen_reference.bin
QUESTIONS=tests/board_questions.tsv
BENCH_RUNS=${BENCH_RUNS:-20}
LOG=board_test_result.txt
STATUS_FILE=.board_test_status.$$
TMP_OUT=.board_test_out.$$
TAB=$(printf '\t')

run_tests() {
    PASS=0; FAIL=0; WARN=0
    pass() { PASS=$((PASS + 1)); echo "[PASS] $*"; }
    fail() { FAIL=$((FAIL + 1)); echo "[FAIL] $*"; }
    warn() { WARN=$((WARN + 1)); echo "[WARN] $*"; }
    finish() {
        echo
        echo "=== Summary: PASS=$PASS FAIL=$FAIL WARN=$WARN ==="
        if [ "$FAIL" -eq 0 ]; then echo "RESULT: PASS"; else echo "RESULT: FAIL"; fi
        echo "$FAIL" > "$STATUS_FILE"
    }

    echo "=== KapraoTiny board test ==="
    echo "date: $(date 2>/dev/null)"
    echo "folder: $(pwd)"
    echo "binary: $BIN"

    echo
    echo "--- 1. System ---"
    echo "uname: $(uname -a 2>/dev/null)"
    ARCH=$(uname -m 2>/dev/null)
    case "$ARCH" in
        armv7*) pass "CPU architecture $ARCH" ;;
        *) warn "uname -m is '$ARCH', not armv7 (expected on a PC dry run; on the board this is a problem)" ;;
    esac
    if [ -r /proc/cpuinfo ]; then
        grep -iE 'model name|Processor|Hardware' /proc/cpuinfo 2>/dev/null | head -n 3
        if grep -qiw neon /proc/cpuinfo; then pass "NEON listed in /proc/cpuinfo"
        else warn "NEON not listed in /proc/cpuinfo; use $SCALAR if the NEON build fails"; fi
    else
        warn "/proc/cpuinfo not readable"
    fi
    if [ -r /proc/meminfo ]; then
        grep -E '^(MemTotal|MemAvailable|MemFree):' /proc/meminfo
    fi
    df -k . 2>/dev/null | tail -n 1 | awk '{print "disk free in this folder: " $4 " KiB"}'
    if mount 2>/dev/null | grep -E " $(df -P . 2>/dev/null | awk 'NR==2{print $6}') " | grep -q noexec; then
        warn "this folder is on a noexec mount; copy the package to /home/root or another ext4 folder"
    fi

    echo
    echo "--- 2. Required files ---"
    for f in "$BIN" "$MODEL" "$GEN" "$REFERENCE" "$GEN_REFERENCE" "$QUESTIONS" SHA256SUMS; do
        if [ -s "$f" ]; then pass "file $f"; else fail "missing or empty: $f"; fi
    done

    echo
    echo "--- 3. Checksum ---"
    if ! command -v sha256sum >/dev/null 2>&1; then
        warn "sha256sum not found; checksum skipped (verify on the PC with check_package.py)"
    elif grep -q "$(printf '\r')" SHA256SUMS; then
        fail "SHA256SUMS has Windows CRLF line endings; copy the file from the latest zip"
    elif sha256sum -c SHA256SUMS > "$TMP_OUT" 2>&1; then
        pass "sha256sum -c SHA256SUMS ($(grep -c ': OK' "$TMP_OUT") files)"
    else
        grep -v ': OK' "$TMP_OUT"
        fail "sha256sum -c SHA256SUMS"
    fi

    echo
    echo "--- 4. Executable ---"
    chmod +x "$BIN" "$SCALAR" 2>/dev/null
    if [ ! -x "$BIN" ]; then
        fail "$BIN is not executable (chmod failed; FAT/noexec mount? copy the folder to /home/root)"
        finish; return
    fi
    if "$BIN" --help > "$TMP_OUT" 2>&1; then
        pass "$BIN starts"
    else
        cat "$TMP_OUT"
        case "$(cat "$TMP_OUT")" in
            *"Exec format"*|*"not found"*|*"syntax error"*)
                echo "hint: Linux must be ARMv7 hard-float; use bin/kaprao_ax7010, not the Windows .exe" ;;
            *"Permission denied"*)
                echo "hint: run chmod +x, and move the folder off a noexec/FAT partition" ;;
        esac
        fail "$BIN does not start"
        finish; return
    fi

    if [ "$QUICK" = 1 ]; then
        echo
        echo "--- 5. Self-test skipped (--quick) ---"
    else
        echo
        echo "--- 5. Self-test (classifier vs Python reference) ---"
        "$BIN" --model "$MODEL" --self-test "$REFERENCE" > "$TMP_OUT" 2>&1
        rc=$?
        cat "$TMP_OUT"
        passed=$(sed -n 's/.*"passed":\([0-9]*\),"total":\([0-9]*\).*/\1/p' "$TMP_OUT")
        total=$(sed -n 's/.*"passed":\([0-9]*\),"total":\([0-9]*\).*/\2/p' "$TMP_OUT")
        if [ $rc -eq 0 ] && [ -n "$total" ] && [ "$passed" = "$total" ]; then
            pass "self-test $passed/$total ($(sed -n 's/.*"runtime":"\([a-z]*\)".*/\1/p' "$TMP_OUT"))"
        else
            fail "self-test exit=$rc"
            if [ "$BIN" != "$SCALAR" ] && [ -x "$SCALAR" ]; then
                echo "diagnose with the scalar build:"
                if "$SCALAR" --model "$MODEL" --self-test "$REFERENCE"; then
                    echo "scalar passes: the NEON path is the suspect; use $SCALAR for now"
                else
                    echo "scalar also fails: check the model/reference files and SHA256SUMS"
                fi
            fi
        fi

        echo
        echo "--- 5b. Generator self-test (greedy text vs Python reference) ---"
        "$BIN" --model "$MODEL" --gen "$GEN" --gen-self-test "$GEN_REFERENCE" > "$TMP_OUT" 2>&1
        rc=$?
        cat "$TMP_OUT"
        passed=$(sed -n 's/.*"generator_passed":\([0-9]*\),"total":\([0-9]*\).*/\1/p' "$TMP_OUT")
        total=$(sed -n 's/.*"generator_passed":\([0-9]*\),"total":\([0-9]*\).*/\2/p' "$TMP_OUT")
        if [ $rc -eq 0 ] && [ -n "$total" ] && [ "$passed" = "$total" ]; then
            pass "generator self-test $passed/$total"
        else
            fail "generator self-test exit=$rc ($passed/$total)"
        fi
    fi

    echo
    echo "--- 6. Question set ($QUESTIONS) ---"
    qpass=0; qtotal=0
    while IFS="$TAB" read -r qid group want_status want_id question; do
        case "$qid" in ''|'#'*) continue ;; esac
        qtotal=$((qtotal + 1))
        out=$("$BIN" --model "$MODEL" --gen "$GEN" --ask "$question" --json 2>&1)
        got_status=$(printf '%s\n' "$out" | sed -n 's/.*"status":"\([a-z_]*\)".*/\1/p')
        got_id=$(printf '%s\n' "$out" | sed -n 's/.*"answer_id":\(-\{0,1\}[0-9]*\).*/\1/p')
        response=$(printf '%s\n' "$out" | sed -n 's/.*"response":"\([^"]*\)".*/\1/p')
        echo "$qid [$group] Q: $question"
        echo "    A: ${response:-$out}"
        if [ "$got_status" = "$want_status" ] && [ "$got_id" = "$want_id" ]; then
            qpass=$((qpass + 1))
        else
            echo "    expected status=$want_status id=$want_id, got status=$got_status id=$got_id"
        fi
    done < "$QUESTIONS"
    if [ "$qtotal" -gt 0 ] && [ "$qpass" -eq "$qtotal" ]; then
        pass "question set $qpass/$qtotal"
    else
        fail "question set $qpass/$qtotal"
    fi

    if [ "$QUICK" = 0 ]; then
        echo
        echo "--- 7. Benchmark ($BENCH_RUNS runs, classifier + generator) ---"
        if "$BIN" --model "$MODEL" --gen "$GEN" --ask "ผัดกะเพราใส่อะไรบ้าง" --benchmark "$BENCH_RUNS" > /dev/null 2> "$TMP_OUT"; then
            cat "$TMP_OUT"
            pass "benchmark finished"
        else
            cat "$TMP_OUT"
            fail "benchmark"
        fi
    fi

    finish
}

echo 1 > "$STATUS_FILE"
run_tests 2>&1 | tee "$LOG"
failures=$(cat "$STATUS_FILE" 2>/dev/null)
rm -f "$STATUS_FILE" "$TMP_OUT"
echo "log saved: $(pwd)/$LOG"
[ "$failures" = 0 ]
