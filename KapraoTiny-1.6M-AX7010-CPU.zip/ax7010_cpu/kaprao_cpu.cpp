// Standalone FP32 KapraoTiny inference. C++17, standard library only.
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cctype>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <numeric>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#ifdef KAPRAO_NEON
#include <arm_neon.h>
#endif
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#endif

using Vec = std::vector<float>;

struct Reader {
    std::ifstream f;
    explicit Reader(const std::string& path) : f(std::filesystem::u8path(path), std::ios::binary) {
        if (!f) throw std::runtime_error("Cannot open model: " + path);
    }
    void bytes(char* dest, size_t n) {
        if (!f.read(dest, static_cast<std::streamsize>(n))) throw std::runtime_error("Truncated model");
    }
    uint32_t u32() {
        unsigned char b[4]; bytes(reinterpret_cast<char*>(b), 4);
        return uint32_t(b[0]) | uint32_t(b[1]) << 8 | uint32_t(b[2]) << 16 | uint32_t(b[3]) << 24;
    }
    float fp32() {
        uint32_t bits = u32(); float value; std::memcpy(&value, &bits, 4);
        if (!std::isfinite(value)) throw std::runtime_error("Non-finite model value");
        return value;
    }
    std::string str() {
        uint32_t n = u32();
        if (n > 1024 * 1024) throw std::runtime_error("Model string too large");
        std::string s(n, '\0'); bytes(s.data(), n); return s;
    }
    std::vector<std::string> strings() {
        uint32_t n = u32();
        if (n > 100000) throw std::runtime_error("Too many model strings");
        std::vector<std::string> result;
        for (uint32_t i = 0; i < n; ++i) result.push_back(str());
        return result;
    }
};

// Split into Unicode scalar values while rejecting malformed UTF-8.
std::vector<std::string> unicode_chars(const std::string& s) {
    std::vector<std::string> result;
    for (size_t i = 0; i < s.size();) {
        unsigned char c = static_cast<unsigned char>(s[i]);
        size_t n = c < 0x80 ? 1 : (c >= 0xc2 && c <= 0xdf ? 2 : (c >= 0xe0 && c <= 0xef ? 3 : (c >= 0xf0 && c <= 0xf4 ? 4 : 0)));
        if (!n || i + n > s.size()) throw std::runtime_error("Invalid UTF-8 input; use a UTF-8 terminal");
        uint32_t cp = c & (n == 1 ? 0x7f : (n == 2 ? 0x1f : (n == 3 ? 0x0f : 0x07)));
        for (size_t k = 1; k < n; ++k) {
            unsigned char tail = static_cast<unsigned char>(s[i + k]);
            if ((tail & 0xc0) != 0x80) throw std::runtime_error("Invalid UTF-8 continuation byte");
            cp = (cp << 6) | (tail & 0x3f);
        }
        if ((n == 2 && cp < 0x80) || (n == 3 && cp < 0x800) || (n == 4 && cp < 0x10000) || cp > 0x10ffff || (cp >= 0xd800 && cp <= 0xdfff)) throw std::runtime_error("Invalid UTF-8 scalar value");
        result.push_back(s.substr(i, n)); i += n;
    }
    return result;
}

struct Tensor { std::vector<uint32_t> shape; Vec data; };

float dot(const float* a, const float* b, size_t n) {
#ifdef KAPRAO_NEON
    float32x4_t acc = vdupq_n_f32(0.0f);
    size_t i = 0;
    for (; i + 4 <= n; i += 4) acc = vmlaq_f32(acc, vld1q_f32(a + i), vld1q_f32(b + i));
    float lanes[4]; vst1q_f32(lanes, acc);
    float sum = (lanes[0] + lanes[1]) + (lanes[2] + lanes[3]);
    for (; i < n; ++i) sum += a[i] * b[i];
#else
    float sum = 0.0f;
    for (size_t i = 0; i < n; ++i) sum += a[i] * b[i];
#endif
    return sum;
}

struct Prediction {
    std::vector<uint32_t> ids;
    Vec logits;
    int answer_id = -1;
    float score = 0.0f;
    std::string status, response;
    double milliseconds = 0.0;
    // Hybrid mode: "classifier", "generator" or "fallback", plus the raw generated text.
    std::string source = "classifier", generated, language = "th";
    bool finished = false;
    float similarity = 0.0f;
};

std::vector<uint32_t> code_points(const std::string& s) {
    std::vector<uint32_t> result;
    for (const auto& ch : unicode_chars(s)) {
        unsigned char c = static_cast<unsigned char>(ch[0]);
        uint32_t cp = c & (ch.size() == 1 ? 0x7f : (ch.size() == 2 ? 0x1f : (ch.size() == 3 ? 0x0f : 0x07)));
        for (size_t k = 1; k < ch.size(); ++k) cp = (cp << 6) | (static_cast<unsigned char>(ch[k]) & 0x3f);
        result.push_back(cp);
    }
    return result;
}

// Python difflib.SequenceMatcher(None, a, b, autojunk=False).ratio(): no junk heuristic,
// and ties pick the same blocks as difflib.
float sequence_ratio(const std::vector<uint32_t>& a, const std::vector<uint32_t>& b) {
    if (a.empty() && b.empty()) return 1.0f;
    struct Range { size_t alo, ahi, blo, bhi; };
    std::vector<Range> queue{{0, a.size(), 0, b.size()}};
    std::vector<size_t> previous(b.size() + 1), current(b.size() + 1);
    size_t matches = 0;
    while (!queue.empty()) {
        Range r = queue.back(); queue.pop_back();
        size_t best_i = r.alo, best_j = r.blo, best = 0;
        std::fill(previous.begin(), previous.end(), 0);
        for (size_t i = r.alo; i < r.ahi; ++i) {
            std::fill(current.begin(), current.end(), 0);
            for (size_t j = r.blo; j < r.bhi; ++j) {
                if (a[i] != b[j]) continue;
                size_t k = current[j + 1] = (j > r.blo ? previous[j] : 0) + 1;
                if (k > best) { best_i = i + 1 - k; best_j = j + 1 - k; best = k; }
            }
            std::swap(previous, current);
        }
        if (!best) continue;
        matches += best;
        if (r.alo < best_i && r.blo < best_j) queue.push_back({r.alo, best_i, r.blo, best_j});
        if (best_i + best < r.ahi && best_j + best < r.bhi) queue.push_back({best_i + best, r.ahi, best_j + best, r.bhi});
    }
    return static_cast<float>(2.0 * matches / static_cast<double>(a.size() + b.size()));
}

const char* score_label(const std::string& language) { return language == "en" ? " (model score " : u8" (คะแนนโมเดล "; }

bool ascii_lower_alnum(const std::string& ch) { return ch.size() == 1 && ((ch[0] >= 'a' && ch[0] <= 'z') || (ch[0] >= '0' && ch[0] <= '9')); }

// Same as kaprao.language: English when there are Latin letters and no Thai characters.
std::string language_of(const std::string& text) {
    bool latin = false, thai = false;
    for (uint32_t cp : code_points(text)) {
        latin = latin || (cp >= 'A' && cp <= 'Z') || (cp >= 'a' && cp <= 'z');
        thai = thai || (cp >= 0x0E00 && cp <= 0x0E7F);
    }
    return latin && !thai ? "en" : "th";
}

class Model {
    std::unordered_map<std::string, Tensor> tensors;
    std::unordered_map<std::string, uint32_t> vocab;
    std::vector<std::string> lexicon, answers, messages, answers_en, messages_en;
    bool english_words = false;  // format 4+: English words are whole tokens
    // Format 5: a message that is only a greeting gets greeting_replies[0] (Thai) or [1] (English).
    std::unordered_set<std::string> greetings, greeting_marks;
    std::vector<std::string> greeting_particles, greeting_replies, greeting_prefixes, help_replies;
    std::unordered_set<std::string> help_phrases;  // "what can you do?" questions
    // Same as kaprao.greeting_key: lowercase, punctuation and whitespace to single spaces, trim,
    // then drop polite endings.
    std::string greeting_key(const std::string& raw) const {
        std::string text; bool pending_space = false;
        for (const auto& ch : unicode_chars(raw)) {
            auto found = lowercase.find(ch);
            for (const auto& c : unicode_chars(found == lowercase.end() ? ch : found->second)) {
                if (whitespace.count(c) || greeting_marks.count(c)) { pending_space = !text.empty(); continue; }
                if (pending_space) text += ' ';
                pending_space = false; text += c;
            }
        }
        for (bool stripped = true; stripped;) {
            stripped = false;
            for (const auto& particle : greeting_particles) {
                if (text.size() > particle.size() && text.compare(text.size() - particle.size(), particle.size(), particle) == 0) {
                    text.erase(text.size() - particle.size());
                    while (!text.empty() && text.back() == ' ') text.pop_back();
                    stripped = true; break;
                }
            }
        }
        return text;
    }
    std::unordered_set<std::string> whitespace;
    std::unordered_map<std::string, std::string> lowercase;
    std::unordered_set<std::string> scope_terms{u8"กะเพรา"};
    float epsilon, threshold, embedding_scale;
    int unknown_answer_id = -1;
    const Tensor& t(const std::string& name) const {
        auto it = tensors.find(name);
        if (it == tensors.end()) throw std::runtime_error("Missing tensor: " + name);
        return it->second;
    }
    void expect(const std::string& name, std::initializer_list<uint32_t> shape) const {
        if (t(name).shape != std::vector<uint32_t>(shape)) throw std::runtime_error("Tensor shape mismatch: " + name);
    }
    Vec dense(const Vec& x, size_t rows, size_t in, size_t out, const Tensor& w, const Tensor& b) const {
        Vec y(rows * out);
        for (size_t r = 0; r < rows; ++r)
            for (size_t j = 0; j < out; ++j)
                y[r * out + j] = dot(x.data() + r * in, w.data.data() + j * in, in) + b.data[j];
        return y;
    }
    Vec norm(const Vec& x, size_t rows, const Tensor& w, const Tensor& b) const {
        Vec y(x.size());
        for (size_t r = 0; r < rows; ++r) {
            const float* row = x.data() + r * dim;
            // Double-precision statistics reduce loss of accuracy from summation.
            double mean = 0.0; for (size_t j = 0; j < dim; ++j) mean += row[j]; mean /= dim;
            double variance = 0.0;
            for (size_t j = 0; j < dim; ++j) { double diff = row[j] - mean; variance += diff * diff; }
            float inv = 1.0f / std::sqrt(static_cast<float>(variance / dim) + epsilon);
            for (size_t j = 0; j < dim; ++j) y[r * dim + j] = (row[j] - static_cast<float>(mean)) * inv * w.data[j] + b.data[j];
        }
        return y;
    }
    Vec attention(const Vec& x, size_t n, const std::string& p) const {
        Vec qkv = dense(x, n, dim, dim * 3, t(p + "self_attn.in_proj_weight"), t(p + "self_attn.in_proj_bias"));
        Vec context(n * dim, 0.0f), probabilities(n);
        size_t width = dim / heads;
        float scale = 1.0f / std::sqrt(static_cast<float>(width));
        for (size_t h = 0; h < heads; ++h) {
            for (size_t i = 0; i < n; ++i) {
                float maximum = -std::numeric_limits<float>::infinity();
                for (size_t j = 0; j < n; ++j) {
                    float score = dot(qkv.data() + i * dim * 3 + h * width, qkv.data() + j * dim * 3 + dim + h * width, width) * scale;
                    probabilities[j] = score; maximum = std::max(maximum, score);
                }
                float denominator = 0.0f;
                for (float& value : probabilities) { value = std::exp(value - maximum); denominator += value; }
                for (float& value : probabilities) value /= denominator;
                for (size_t j = 0; j < n; ++j) {
                    const float* values = qkv.data() + j * dim * 3 + dim * 2 + h * width;
                    for (size_t k = 0; k < width; ++k) context[i * dim + h * width + k] += probabilities[j] * values[k];
                }
            }
        }
        return dense(context, n, dim, dim, t(p + "self_attn.out_proj.weight"), t(p + "self_attn.out_proj.bias"));
    }
public:
    uint32_t dim, layers, heads, ffn, max_len;
    size_t parameter_count = 0;
    const std::unordered_set<std::string>& whitespace_set() const { return whitespace; }
    bool is_greeting(const std::string& question) const { return !greetings.empty() && greetings.count(greeting_key(question)) > 0; }
    // Same as kaprao.is_help: Thai phrases also match with the spaces removed.
    bool is_help(const std::string& question) const {
        if (help_phrases.empty()) return false;
        auto key = greeting_key(question);
        std::string compact; for (char c : key) if (c != ' ') compact += c;
        return help_phrases.count(key) > 0 || help_phrases.count(compact) > 0;
    }
    // Same as kaprao.strip_greeting: drop a leading greeting (plus polite endings and punctuation)
    // from a longer question, because the models never saw greetings in training.
    std::string strip_greeting(const std::string& question) const {
        auto chars = unicode_chars(question);
        size_t start = 0;
        while (start < chars.size() && whitespace.count(chars[start])) ++start;
        auto lower = [&](const std::string& ch) { auto found = lowercase.find(ch); return found == lowercase.end() ? ch : found->second; };
        for (const auto& greeting : greeting_prefixes) {
            auto want = unicode_chars(greeting);
            if (start + want.size() > chars.size()) continue;
            std::string got;
            for (size_t k = 0; k < want.size(); ++k) got += lower(chars[start + k]);
            if (got != greeting) continue;
            size_t pos = start + want.size();
            bool ascii_greeting = std::all_of(greeting.begin(), greeting.end(), [](char c) { return static_cast<unsigned char>(c) < 0x80; });
            if (ascii_greeting && pos < chars.size() && chars[pos].size() == 1 && std::isalnum(static_cast<unsigned char>(chars[pos][0]))) continue;
            std::string rest; for (size_t k = pos; k < chars.size(); ++k) rest += chars[k];
            for (bool found = true; found;) {
                auto rc = unicode_chars(rest); size_t s = 0;
                while (s < rc.size() && whitespace.count(rc[s])) ++s;
                std::string trimmed; for (size_t k = s; k < rc.size(); ++k) trimmed += rc[k];
                rest = trimmed; found = false;
                for (const auto& particle : greeting_particles) if (rest.compare(0, particle.size(), particle) == 0) { rest.erase(0, particle.size()); found = true; break; }
            }
            auto rc = unicode_chars(rest); size_t s = 0;
            while (s < rc.size() && (whitespace.count(rc[s]) || greeting_marks.count(rc[s]))) ++s;
            std::string remainder; for (size_t k = s; k < rc.size(); ++k) remainder += rc[k];
            if (!remainder.empty()) return remainder;
        }
        return question;
    }
    explicit Model(const std::string& path) {
        static_assert(sizeof(float) == 4 && std::numeric_limits<float>::is_iec559, "Requires IEEE754 float32");
        Reader reader(path); char magic[8]; reader.bytes(magic, 8);
        if (std::memcmp(magic, "KAPRAO1\0", 8) != 0) throw std::runtime_error("Unsupported model magic");
        uint32_t version = reader.u32();
        if (version < 1 || version > 5) throw std::runtime_error("Unsupported model format/version");
        dim = reader.u32(); layers = reader.u32(); heads = reader.u32(); ffn = reader.u32(); max_len = reader.u32();
        uint32_t vocab_size = reader.u32(), classes = reader.u32();
        if (!dim || dim > 1024 || !layers || layers > 24 || !heads || dim % heads || !ffn || ffn > 4096 || !max_len || max_len > 512 || vocab_size < 2 || vocab_size > 65536 || !classes || classes > 4096) throw std::runtime_error("Invalid model configuration");
        if (version >= 2) {
            uint32_t id = reader.u32();
            if (id >= classes) throw std::runtime_error("Unknown-answer class outside classifier range");
            unknown_answer_id = static_cast<int>(id);
        }
        epsilon = reader.fp32(); threshold = reader.fp32(); embedding_scale = reader.fp32();
        if (epsilon <= 0 || threshold <= 0 || threshold >= 1 || embedding_scale <= 0) throw std::runtime_error("Invalid model constants");
        auto words = reader.strings();
        if (words.size() != vocab_size || words[0] != "<pad>" || words[1] != "<unk>") throw std::runtime_error("Invalid vocabulary");
        for (uint32_t i = 0; i < words.size(); ++i) if (!vocab.emplace(words[i], i).second) throw std::runtime_error("Duplicate vocabulary entry");
        lexicon = reader.strings(); answers = reader.strings(); messages = reader.strings();
        if (lexicon.empty() || answers.size() != classes || messages.size() != 4) throw std::runtime_error("Invalid model text metadata");
        for (const auto& s : lexicon) if (s.empty()) throw std::runtime_error("Empty tokenizer term");
        if (version >= 3) {
            auto terms = reader.strings();
            if (terms.empty()) throw std::runtime_error("Empty scope term list");
            scope_terms = std::unordered_set<std::string>(terms.begin(), terms.end());
        }
        if (version >= 4) {
            answers_en = reader.strings(); messages_en = reader.strings();
            if (answers_en.size() != classes || messages_en.size() != 4) throw std::runtime_error("Invalid English text metadata");
            english_words = true;
        }
        if (version >= 5) {
            auto words = reader.strings(); greeting_particles = reader.strings();
            auto marks = reader.strings(); greeting_replies = reader.strings(); greeting_prefixes = reader.strings();
            auto phrases = reader.strings(); help_replies = reader.strings();
            if (words.empty() || greeting_replies.size() != 2 || phrases.empty() || help_replies.size() != 2) throw std::runtime_error("Invalid greeting/help metadata");
            help_phrases = std::unordered_set<std::string>(phrases.begin(), phrases.end());
            greetings = std::unordered_set<std::string>(words.begin(), words.end());
            greeting_marks = std::unordered_set<std::string>(marks.begin(), marks.end());
        }
        for (const auto& s : reader.strings()) whitespace.insert(s);
        uint32_t lower_count = reader.u32();
        if (lower_count > 100000) throw std::runtime_error("Too many Unicode mappings");
        for (uint32_t i = 0; i < lower_count; ++i) { auto key = reader.str(); auto value = reader.str(); lowercase.emplace(key, value); }
        uint32_t tensor_count = reader.u32();
        if (tensor_count > 1000) throw std::runtime_error("Too many tensors");
        for (uint32_t i = 0; i < tensor_count; ++i) {
            std::string name = reader.str(); Tensor tensor;
            uint32_t rank = reader.u32(); if (rank > 4) throw std::runtime_error("Invalid tensor rank");
            uint64_t count = 1;
            for (uint32_t j = 0; j < rank; ++j) { auto size = reader.u32(); if (!size || size > 100000 || count > 100000000 / size) throw std::runtime_error("Invalid tensor dimensions"); tensor.shape.push_back(size); count *= size; }
            if (reader.u32() != count * 4 || count > 20000000 || parameter_count + count > 25000000) throw std::runtime_error("Invalid tensor byte count");
            tensor.data.resize(static_cast<size_t>(count));
            for (float& value : tensor.data) value = reader.fp32();
            parameter_count += count;
            if (!tensors.emplace(name, std::move(tensor)).second) throw std::runtime_error("Duplicate tensor");
        }
        if (reader.f.peek() != std::char_traits<char>::eof()) throw std::runtime_error("Unexpected trailing model bytes");
        expect("token.weight", {vocab_size, dim}); expect("position.weight", {max_len, dim});
        for (uint32_t i = 0; i < layers; ++i) {
            std::string p = "encoder.layers." + std::to_string(i) + ".";
            expect(p + "self_attn.in_proj_weight", {3 * dim, dim}); expect(p + "self_attn.in_proj_bias", {3 * dim});
            expect(p + "self_attn.out_proj.weight", {dim, dim}); expect(p + "self_attn.out_proj.bias", {dim});
            expect(p + "linear1.weight", {ffn, dim}); expect(p + "linear1.bias", {ffn});
            expect(p + "linear2.weight", {dim, ffn}); expect(p + "linear2.bias", {dim});
            for (const auto& name : {"norm1", "norm2"}) { expect(p + name + ".weight", {dim}); expect(p + name + ".bias", {dim}); }
        }
        expect("encoder.norm.weight", {dim}); expect("encoder.norm.bias", {dim});
        expect("classifier.weight", {classes, dim}); expect("classifier.bias", {classes});
    }
    std::vector<std::string> tokenize(const std::string& raw) const {
        std::string lowered;
        for (const auto& ch : unicode_chars(raw)) { auto found = lowercase.find(ch); lowered += found == lowercase.end() ? ch : found->second; }
        const std::string wrong = u8"กระเพรา", right = u8"กะเพรา";
        for (size_t pos = 0; (pos = lowered.find(wrong, pos)) != std::string::npos; pos += right.size()) lowered.replace(pos, wrong.size(), right);
        // Drop whitespace (Thai has no word spaces); format 4 keeps one space between two ASCII
        // letters/digits so English words stay apart, as kaprao.tokenize does.
        auto chars = unicode_chars(lowered);
        size_t begin = 0, end = chars.size();
        while (begin < end && whitespace.count(chars[begin])) ++begin;
        while (end > begin && whitespace.count(chars[end - 1])) --end;
        std::string text;
        for (size_t k = begin; k < end;) {
            if (!whitespace.count(chars[k])) { text += chars[k++]; continue; }
            size_t next = k; while (next < end && whitespace.count(chars[next])) ++next;
            if (english_words && ascii_lower_alnum(chars[k - 1]) && ascii_lower_alnum(chars[next])) text += ' ';
            k = next;
        }
        std::vector<std::string> result;
        for (size_t i = 0; i < text.size();) {
            if (english_words && text[i] == ' ') { ++i; continue; }
            std::string term;
            if (english_words && text[i] >= 'a' && text[i] <= 'z') {
                size_t j = i; while (j < text.size() && text[j] >= 'a' && text[j] <= 'z') ++j;
                term = text.substr(i, j - i);
            }
            if (term.empty()) for (const auto& word : lexicon) if (text.compare(i, word.size(), word) == 0) { term = word; break; }
            if (term.empty()) {
                unsigned char c = static_cast<unsigned char>(text[i]);
                size_t bytes = c < 0x80 ? 1 : (c < 0xe0 ? 2 : (c < 0xf0 ? 3 : 4));
                term = text.substr(i, bytes);
            }
            result.push_back(term); i += term.size();
        }
        return result;
    }
    std::vector<uint32_t> encode(const std::vector<std::string>& tokens) const {
        std::vector<uint32_t> ids;
        for (size_t i = 0; i < std::min(tokens.size(), size_t(max_len)); ++i) { auto it = vocab.find(tokens[i]); ids.push_back(it == vocab.end() ? 1 : it->second); }
        return ids;
    }
    Vec forward(std::vector<uint32_t> ids) const {
        // The single-question path contains no padding; match Python's blank guard.
        if (ids.empty()) ids.push_back(1);
        size_t n = ids.size(); Vec x(n * dim);
        const auto& tokens = t("token.weight").data; const auto& positions = t("position.weight").data;
        for (size_t r = 0; r < n; ++r) for (size_t j = 0; j < dim; ++j) x[r * dim + j] = tokens[ids[r] * dim + j] * embedding_scale + positions[r * dim + j];
        for (uint32_t layer = 0; layer < layers; ++layer) {
            std::string p = "encoder.layers." + std::to_string(layer) + ".";
            Vec a = norm(x, n, t(p + "norm1.weight"), t(p + "norm1.bias"));
            a = attention(a, n, p);
            for (size_t i = 0; i < x.size(); ++i) x[i] += a[i];
            a = norm(x, n, t(p + "norm2.weight"), t(p + "norm2.bias"));
            a = dense(a, n, dim, ffn, t(p + "linear1.weight"), t(p + "linear1.bias"));
            for (float& value : a) value = std::max(0.0f, value);
            a = dense(a, n, ffn, dim, t(p + "linear2.weight"), t(p + "linear2.bias"));
            for (size_t i = 0; i < x.size(); ++i) x[i] += a[i];
        }
        x = norm(x, n, t("encoder.norm.weight"), t("encoder.norm.bias"));
        Vec pooled(dim, 0.0f);
        for (size_t r = 0; r < n; ++r) for (size_t j = 0; j < dim; ++j) pooled[j] += x[r * dim + j];
        for (float& value : pooled) value /= static_cast<float>(n);
        return dense(pooled, 1, dim, answers.size(), t("classifier.weight"), t("classifier.bias"));
    }
    Prediction predict(const std::string& original, bool raw = false) const {
        auto start = std::chrono::steady_clock::now(); Prediction result;
        bool greeting = !raw && is_greeting(original);
        const std::string question = greeting || raw ? original : strip_greeting(original);
        result.language = language_of(question);
        bool en = result.language == "en" && !answers_en.empty();
        const auto& said = en ? answers_en : answers;
        const auto& note = en ? messages_en : messages;
        auto tokens = tokenize(question); result.ids = encode(tokens);
        auto visible_end = tokens.begin() + std::min(tokens.size(), size_t(max_len));
        bool in_scope = std::any_of(tokens.begin(), visible_end, [&](const std::string& token) { return scope_terms.count(token) > 0; });
        if (greeting) { result.status = "greeting"; result.source = "greeting"; result.response = greeting_replies[result.language == "en" ? 1 : 0]; }
        else if (!raw && is_help(question)) { result.status = "help"; result.source = "help"; result.response = help_replies[result.language == "en" ? 1 : 0]; }
        else if (!raw && tokens.empty()) { result.status = "empty"; result.response = note[1]; }
        else if (!raw && !in_scope) { result.status = "out_of_scope"; result.response = note[0]; }
        else {
            result.logits = forward(result.ids);
            for (float value : result.logits) if (!std::isfinite(value)) throw std::runtime_error("Inference produced a non-finite logit");
            auto maximum = std::max_element(result.logits.begin(), result.logits.end());
            result.answer_id = static_cast<int>(maximum - result.logits.begin());
            float total = 0.0f; for (float value : result.logits) total += std::exp(value - *maximum);
            result.score = 1.0f / total;
            result.status = result.answer_id == unknown_answer_id ? "unsupported" : (result.score >= threshold ? "answer" : "low_confidence");
            std::ostringstream text; text << std::fixed << std::setprecision(0);
            if (result.status == "unsupported") text << said[result.answer_id];
            else if (result.status == "answer") text << said[result.answer_id] << score_label(result.language) << result.score * 100 << "%)";
            else text << note[2] << " (" << result.score * 100 << "%) " << note[3];
            result.response = text.str();
        }
        result.milliseconds = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
        return result;
    }
};


// Decoder-only generator (pre-norm Transformer with a causal mask) with KV-cache decoding.
class Generator {
    enum { PAD, UNK, BOS, SEP, EOS, SPECIAL_COUNT };
    std::unordered_map<std::string, Tensor> tensors;
    std::unordered_map<std::string, uint32_t> vocab;
    std::vector<std::string> words, lexicon;
    std::map<int, uint32_t> class_token;
    // Index 0 = Thai, 1 = English.
    std::map<int, std::vector<std::vector<uint32_t>>> variants[2];
    std::map<int, std::unordered_set<std::string>> verified[2];
    uint32_t language_token[2] = {0, 0};
    static int language_index(const std::string& language) { return language == "en" ? 1 : 0; }
    float epsilon, embedding_scale;
    const Tensor& t(const std::string& name) const {
        auto it = tensors.find(name);
        if (it == tensors.end()) throw std::runtime_error("Missing generator tensor: " + name);
        return it->second;
    }
    void expect(const std::string& name, std::initializer_list<uint32_t> shape) const {
        if (t(name).shape != std::vector<uint32_t>(shape)) throw std::runtime_error("Generator tensor shape mismatch: " + name);
    }
    void norm(const float* x, float* y, const Tensor& w, const Tensor& b) const {
        double mean = 0.0; for (size_t j = 0; j < dim; ++j) mean += x[j]; mean /= dim;
        double variance = 0.0; for (size_t j = 0; j < dim; ++j) { double d = x[j] - mean; variance += d * d; }
        float inv = 1.0f / std::sqrt(static_cast<float>(variance / dim) + epsilon);
        for (size_t j = 0; j < dim; ++j) y[j] = (x[j] - static_cast<float>(mean)) * inv * w.data[j] + b.data[j];
    }
    void dense(const float* x, size_t in, size_t out, const Tensor& w, const Tensor* b, float* y) const {
        for (size_t j = 0; j < out; ++j) y[j] = dot(x, w.data.data() + j * in, in) + (b ? b->data[j] : 0.0f);
    }
public:
    uint32_t dim, layers, heads, ffn, max_len, max_question, max_answer;
    int guard_attempts = 1;
    size_t parameter_count = 0;
    explicit Generator(const std::string& path) {
        Reader reader(path); char magic[8]; reader.bytes(magic, 8);
        if (std::memcmp(magic, "KAPGEN1\0", 8) != 0) throw std::runtime_error("Unsupported generator magic");
        if (reader.u32() != 2) throw std::runtime_error("Unsupported generator version (needs format 2)");
        dim = reader.u32(); layers = reader.u32(); heads = reader.u32(); ffn = reader.u32(); max_len = reader.u32();
        uint32_t vocab_size = reader.u32(); max_question = reader.u32(); max_answer = reader.u32();
        if (!dim || dim > 1024 || !layers || layers > 24 || !heads || dim % heads || !ffn || ffn > 4096 || !max_len || max_len > 1024 || vocab_size <= SPECIAL_COUNT || vocab_size > 65536 || !max_answer || max_question + 4 + max_answer > max_len)
            throw std::runtime_error("Invalid generator configuration");
        epsilon = reader.fp32(); float attempts = reader.fp32(); embedding_scale = reader.fp32();
        if (epsilon <= 0 || attempts < 1 || attempts > 20 || embedding_scale <= 0) throw std::runtime_error("Invalid generator constants");
        guard_attempts = static_cast<int>(attempts);
        words = reader.strings();
        const char* special[] = {"<pad>", "<unk>", "<bos>", "<sep>", "<eos>"};
        if (words.size() != vocab_size) throw std::runtime_error("Invalid generator vocabulary");
        for (int i = 0; i < SPECIAL_COUNT; ++i) if (words[i] != special[i]) throw std::runtime_error("Invalid generator special tokens");
        for (uint32_t i = 0; i < words.size(); ++i) if (!vocab.emplace(words[i], i).second) throw std::runtime_error("Duplicate generator vocabulary entry");
        lexicon = reader.strings();
        uint32_t classes = reader.u32();
        if (!classes || SPECIAL_COUNT + classes > vocab_size) throw std::runtime_error("Invalid generator class count");
        for (uint32_t i = 0; i < classes; ++i) {
            int answer_id = static_cast<int>(reader.u32());
            if (class_token.count(answer_id)) throw std::runtime_error("Duplicate generator answer ID");
            class_token[answer_id] = SPECIAL_COUNT + i;
            for (int lang = 0; lang < 2; ++lang) {
                auto texts = reader.strings();
                if (texts.empty()) throw std::runtime_error("Generator answer has no verified sentences");
                for (const auto& text : texts) { variants[lang][answer_id].push_back(code_points(text)); verified[lang][answer_id].insert(text); }
            }
        }
        const char* language_names[] = {"<th>", "<en>"};
        for (int lang = 0; lang < 2; ++lang) {
            language_token[lang] = SPECIAL_COUNT + classes + lang;
            if (language_token[lang] >= vocab_size || words[language_token[lang]] != language_names[lang]) throw std::runtime_error("Invalid generator language tokens");
        }
        uint32_t tensor_count = reader.u32();
        if (tensor_count > 1000) throw std::runtime_error("Too many generator tensors");
        for (uint32_t i = 0; i < tensor_count; ++i) {
            std::string name = reader.str(); Tensor tensor;
            uint32_t rank = reader.u32(); if (rank > 4) throw std::runtime_error("Invalid tensor rank");
            uint64_t count = 1;
            for (uint32_t j = 0; j < rank; ++j) { auto size = reader.u32(); if (!size || size > 100000 || count > 100000000 / size) throw std::runtime_error("Invalid tensor dimensions"); tensor.shape.push_back(size); count *= size; }
            if (reader.u32() != count * 4 || count > 20000000 || parameter_count + count > 25000000) throw std::runtime_error("Invalid tensor byte count");
            tensor.data.resize(static_cast<size_t>(count));
            for (float& value : tensor.data) value = reader.fp32();
            parameter_count += count;
            if (!tensors.emplace(name, std::move(tensor)).second) throw std::runtime_error("Duplicate generator tensor");
        }
        if (reader.f.peek() != std::char_traits<char>::eof()) throw std::runtime_error("Unexpected trailing generator bytes");
        expect("token.weight", {vocab_size, dim}); expect("position.weight", {max_len, dim});
        for (uint32_t i = 0; i < layers; ++i) {
            std::string p = "blocks.layers." + std::to_string(i) + ".";
            expect(p + "self_attn.in_proj_weight", {3 * dim, dim}); expect(p + "self_attn.in_proj_bias", {3 * dim});
            expect(p + "self_attn.out_proj.weight", {dim, dim}); expect(p + "self_attn.out_proj.bias", {dim});
            expect(p + "linear1.weight", {ffn, dim}); expect(p + "linear1.bias", {ffn});
            expect(p + "linear2.weight", {dim, ffn}); expect(p + "linear2.bias", {dim});
            for (const auto& name : {"norm1", "norm2"}) { expect(p + name + ".weight", {dim}); expect(p + name + ".bias", {dim}); }
        }
        expect("blocks.norm.weight", {dim}); expect("blocks.norm.bias", {dim});
    }
    bool supports(int answer_id) const { return class_token.count(answer_id) > 0; }
    // Same as kaprao_hybrid.gen_tokenize: strip, fix spelling, collapse whitespace runs, keep case;
    // English words (ASCII letter runs) are single tokens.
    std::vector<std::string> tokenize(const std::string& raw, const std::unordered_set<std::string>& whitespace) const {
        auto chars = unicode_chars(raw);
        size_t begin = 0, end = chars.size();
        while (begin < end && whitespace.count(chars[begin])) ++begin;
        while (end > begin && whitespace.count(chars[end - 1])) --end;
        std::string fixed; for (size_t i = begin; i < end; ++i) fixed += chars[i];
        const std::string wrong = u8"กระเพรา", right = u8"กะเพรา";
        for (size_t pos = 0; (pos = fixed.find(wrong, pos)) != std::string::npos; pos += right.size()) fixed.replace(pos, wrong.size(), right);
        std::string text; bool in_space = false;
        for (const auto& ch : unicode_chars(fixed)) {
            if (whitespace.count(ch)) { if (!in_space) text += ' '; in_space = true; }
            else { text += ch; in_space = false; }
        }
        std::vector<std::string> result;
        auto letter = [](char c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'); };
        for (size_t i = 0; i < text.size();) {
            std::string term;
            if (letter(text[i])) { size_t j = i; while (j < text.size() && letter(text[j])) ++j; term = text.substr(i, j - i); }
            if (term.empty()) for (const auto& word : lexicon) if (text.compare(i, word.size(), word) == 0) { term = word; break; }
            if (term.empty()) {
                unsigned char c = static_cast<unsigned char>(text[i]);
                term = text.substr(i, c < 0x80 ? 1 : (c < 0xe0 ? 2 : (c < 0xf0 ? 3 : 4)));
            }
            result.push_back(term); i += term.size();
        }
        return result;
    }
    std::vector<uint32_t> prompt(const std::string& question, int answer_id, const std::unordered_set<std::string>& whitespace, const std::string& language) const {
        auto found = class_token.find(answer_id);
        if (found == class_token.end()) throw std::runtime_error("Generator has no category " + std::to_string(answer_id));
        std::vector<uint32_t> ids{BOS, found->second, language_token[language_index(language)]};
        auto tokens = tokenize(question, whitespace);
        for (size_t i = 0; i < std::min(tokens.size(), size_t(max_question)); ++i) { auto it = vocab.find(tokens[i]); ids.push_back(it == vocab.end() ? uint32_t(UNK) : it->second); }
        ids.push_back(SEP);
        return ids;
    }
    struct Result { std::string text; bool finished = false; Vec first_logits; };
    // Feeds the prompt and each generated token through a KV cache, one position at a time.
    Result generate(const std::vector<uint32_t>& prompt_ids, float temperature, std::mt19937& rng) const {
        size_t width = dim / heads; float scale = 1.0f / std::sqrt(static_cast<float>(width));
        std::vector<Vec> keys(layers, Vec(size_t(max_len) * dim)), values(layers, Vec(size_t(max_len) * dim));
        Vec x(dim), a(dim), qkv(3 * dim), context(dim), hidden(ffn), out(dim), logits(words.size()), scores(max_len);
        const auto& token_weight = t("token.weight"); const auto& positions = t("position.weight").data;
        Result result; std::vector<uint32_t> ids = prompt_ids; std::string text;
        size_t generated = 0;
        for (size_t pos = 0; pos < ids.size() && pos < max_len; ++pos) {
            for (size_t j = 0; j < dim; ++j) x[j] = token_weight.data[ids[pos] * dim + j] * embedding_scale + positions[pos * dim + j];
            for (uint32_t layer = 0; layer < layers; ++layer) {
                std::string p = "blocks.layers." + std::to_string(layer) + ".";
                norm(x.data(), a.data(), t(p + "norm1.weight"), t(p + "norm1.bias"));
                dense(a.data(), dim, 3 * dim, t(p + "self_attn.in_proj_weight"), &t(p + "self_attn.in_proj_bias"), qkv.data());
                std::copy(qkv.begin() + dim, qkv.begin() + 2 * dim, keys[layer].begin() + pos * dim);
                std::copy(qkv.begin() + 2 * dim, qkv.end(), values[layer].begin() + pos * dim);
                std::fill(context.begin(), context.end(), 0.0f);
                for (size_t h = 0; h < heads; ++h) {
                    float maximum = -std::numeric_limits<float>::infinity();
                    for (size_t j = 0; j <= pos; ++j) { scores[j] = dot(qkv.data() + h * width, keys[layer].data() + j * dim + h * width, width) * scale; maximum = std::max(maximum, scores[j]); }
                    float denominator = 0.0f;
                    for (size_t j = 0; j <= pos; ++j) { scores[j] = std::exp(scores[j] - maximum); denominator += scores[j]; }
                    for (size_t j = 0; j <= pos; ++j) {
                        float weight = scores[j] / denominator; const float* v = values[layer].data() + j * dim + h * width;
                        for (size_t k = 0; k < width; ++k) context[h * width + k] += weight * v[k];
                    }
                }
                dense(context.data(), dim, dim, t(p + "self_attn.out_proj.weight"), &t(p + "self_attn.out_proj.bias"), out.data());
                for (size_t j = 0; j < dim; ++j) x[j] += out[j];
                norm(x.data(), a.data(), t(p + "norm2.weight"), t(p + "norm2.bias"));
                dense(a.data(), dim, ffn, t(p + "linear1.weight"), &t(p + "linear1.bias"), hidden.data());
                for (float& value : hidden) value = std::max(0.0f, value);
                dense(hidden.data(), ffn, dim, t(p + "linear2.weight"), &t(p + "linear2.bias"), out.data());
                for (size_t j = 0; j < dim; ++j) x[j] += out[j];
            }
            if (pos + 1 < ids.size()) continue;  // still reading the prompt
            norm(x.data(), a.data(), t("blocks.norm.weight"), t("blocks.norm.bias"));
            dense(a.data(), dim, words.size(), token_weight, nullptr, logits.data());
            if (result.first_logits.empty()) result.first_logits = logits;
            if (generated == max_answer) break;
            for (uint32_t id : {PAD, UNK, BOS, SEP}) logits[id] = -std::numeric_limits<float>::infinity();
            for (size_t id = SPECIAL_COUNT; id < SPECIAL_COUNT + class_token.size() + 2; ++id) logits[id] = -std::numeric_limits<float>::infinity();
            uint32_t next;
            if (temperature > 0) {
                float maximum = *std::max_element(logits.begin(), logits.end());
                std::vector<double> weights(logits.size());
                for (size_t j = 0; j < logits.size(); ++j) weights[j] = std::isfinite(logits[j]) ? std::exp((logits[j] - maximum) / temperature) : 0.0;
                next = static_cast<uint32_t>(std::discrete_distribution<size_t>(weights.begin(), weights.end())(rng));
            } else next = static_cast<uint32_t>(std::max_element(logits.begin(), logits.end()) - logits.begin());
            if (next == EOS) { result.finished = true; break; }
            ++generated; text += words[next]; ids.push_back(next);
        }
        // Python strips surrounding spaces from the joined text.
        size_t first = text.find_first_not_of(' '), last = text.find_last_not_of(' ');
        result.text = first == std::string::npos ? "" : text.substr(first, last - first + 1);
        return result;
    }
    // The guard: only verified sentences for the category are shown.
    bool accepts(const Result& r, int answer_id, const std::string& language) const { return r.finished && verified[language_index(language)].at(answer_id).count(r.text) > 0; }
    float similarity(const std::string& text, int answer_id, const std::string& language) const {
        auto a = code_points(text); float best = 0.0f;
        for (const auto& b : variants[language_index(language)].at(answer_id)) best = std::max(best, sequence_ratio(a, b));
        return best;
    }
};

// Classifier first; for answerable categories the generator writes the reply and the guard checks it.
Prediction hybrid_predict(const Model& model, const Generator* generator, const std::string& question, bool raw, float temperature, std::mt19937& rng) {
    Prediction result = model.predict(question, raw);
    if (!generator || result.status != "answer" || !generator->supports(result.answer_id)) return result;
    auto start = std::chrono::steady_clock::now();
    auto prompt = generator->prompt(raw ? question : model.strip_greeting(question), result.answer_id, model.whitespace_set(), result.language);
    Generator::Result generated;
    for (int attempt = 0; attempt < (temperature > 0 ? generator->guard_attempts : 1); ++attempt) {
        generated = generator->generate(prompt, temperature, rng);
        if (generator->accepts(generated, result.answer_id, result.language)) break;
    }
    result.generated = generated.text; result.finished = generated.finished;
    result.similarity = generator->similarity(generated.text, result.answer_id, result.language);
    if (generator->accepts(generated, result.answer_id, result.language)) {
        result.source = "generator";
        std::ostringstream text; text << std::fixed << std::setprecision(0) << generated.text << score_label(result.language) << result.score * 100 << "%)";
        result.response = text.str();
    } else result.source = "fallback";  // keep the classifier's fixed answer
    result.milliseconds += std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
    return result;
}

int generator_self_test(const Model& model, const Generator& generator, const std::string& path) {
    Reader reference(path); char magic[8]; reference.bytes(magic, 8);
    if (std::memcmp(magic, "KAPGTST1", 8) != 0) throw std::runtime_error("Invalid generator reference format");
    uint32_t count = reference.u32();
    if (!count || count > 10000) throw std::runtime_error("Invalid generator reference count");
    size_t passed = 0, text_mismatch = 0; double max_error = 0.0, max_similarity_error = 0.0, total_ms = 0.0;
    std::mt19937 rng(0);
    for (uint32_t i = 0; i < count; ++i) {
        auto question = reference.str(); int answer_id = static_cast<int>(reference.u32());
        uint32_t n = reference.u32(); if (n > generator.max_len) throw std::runtime_error("Invalid reference prompt length");
        std::vector<uint32_t> prompt(n); for (auto& id : prompt) id = reference.u32();
        auto text = reference.str(); bool finished = reference.u32() != 0; float similarity = reference.fp32();
        n = reference.u32(); if (n > 65536) throw std::runtime_error("Invalid reference logit count");
        Vec logits(n); for (float& value : logits) value = reference.fp32();
        auto start = std::chrono::steady_clock::now();
        auto language = language_of(question);
        auto actual_prompt = generator.prompt(question, answer_id, model.whitespace_set(), language);
        auto actual = generator.generate(actual_prompt, 0.0f, rng);
        float actual_similarity = generator.similarity(actual.text, answer_id, language);
        total_ms += std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
        double error = actual.first_logits.size() == logits.size() ? 0.0 : 1e9;
        if (!error) for (size_t j = 0; j < logits.size(); ++j) error = std::max(error, double(std::abs(logits[j] - actual.first_logits[j])));
        double similarity_error = std::abs(actual_similarity - similarity);
        max_error = std::max(max_error, error); max_similarity_error = std::max(max_similarity_error, similarity_error);
        bool same_text = actual.text == text && actual.finished == finished;
        if (!same_text) ++text_mismatch;
        bool ok = actual_prompt == prompt && same_text && error <= 0.0005 && similarity_error <= 0.00001;
        if (ok) ++passed;
        else std::cerr << "FAIL generator case " << i << ": " << question << "; prompt_match=" << (actual_prompt == prompt) << ", text_match=" << same_text << ", max_logit_error=" << error << ", similarity_error=" << similarity_error << '\n';
    }
    if (reference.f.peek() != std::char_traits<char>::eof()) throw std::runtime_error("Trailing generator reference data");
    std::cout << std::setprecision(9) << "{\"generator_passed\":" << passed << ",\"total\":" << count << ",\"text_mismatches\":" << text_mismatch << ",\"max_first_logit_error\":" << max_error << ",\"max_similarity_error\":" << max_similarity_error << ",\"total_generation_ms\":" << total_ms << "}\n";
    return passed == count ? 0 : 1;
}

std::string json_string(const std::string& text) {
    std::ostringstream out; out << '"';
    for (unsigned char c : text) {
        if (c == '"' || c == '\\') out << '\\' << c;
        else if (c < 0x20) out << "\\u00" << std::hex << std::setw(2) << std::setfill('0') << unsigned(c) << std::dec;
        else out << c;
    }
    out << '"'; return out.str();
}

void print_prediction(const Prediction& p) {
    std::cout << std::setprecision(9) << "{\"status\":" << json_string(p.status) << ",\"answer_id\":" << p.answer_id << ",\"score\":" << p.score << ",\"milliseconds\":" << p.milliseconds << ",\"response\":" << json_string(p.response) << ",\"ids\":[";
    for (size_t i = 0; i < p.ids.size(); ++i) { if (i) std::cout << ','; std::cout << p.ids[i]; }
    std::cout << "],\"logits\":[";
    for (size_t i = 0; i < p.logits.size(); ++i) { if (i) std::cout << ','; std::cout << p.logits[i]; }
    std::cout << "],\"source\":" << json_string(p.source) << ",\"generated\":" << json_string(p.generated) << ",\"finished\":" << (p.finished ? "true" : "false") << ",\"similarity\":" << p.similarity << "}\n";
}

int self_test(const Model& model, const std::string& path) {
    Reader reference(path); char magic[8]; reference.bytes(magic, 8);
    if (std::memcmp(magic, "KAPTEST1", 8) != 0) throw std::runtime_error("Invalid reference format");
    uint32_t count = reference.u32();
    if (!count || count > 10000) throw std::runtime_error("Invalid reference count");
    size_t passed = 0; double max_error = 0.0, max_score_error = 0.0, total_ms = 0.0;
    for (uint32_t i = 0; i < count; ++i) {
        bool raw = reference.u32() != 0;
        auto question = reference.str(), status = reference.str();
        uint32_t encoded_id = reference.u32();
        int expected_id = encoded_id == 0xffffffff ? -1 : static_cast<int>(encoded_id);
        float expected_score = reference.fp32();
        uint32_t n = reference.u32();
        if (n > model.max_len) throw std::runtime_error("Invalid reference token count");
        std::vector<uint32_t> ids(n); for (auto& value : ids) value = reference.u32();
        n = reference.u32(); if (n > 4096) throw std::runtime_error("Invalid reference logit count");
        Vec logits(n); for (float& value : logits) value = reference.fp32();
        auto actual = model.predict(question, raw);
        bool ok = actual.status == status && actual.answer_id == expected_id && actual.ids == ids && actual.logits.size() == logits.size();
        double error = 0.0;
        if (actual.logits.size() == logits.size()) for (size_t j = 0; j < logits.size(); ++j) error = std::max(error, double(std::abs(logits[j] - actual.logits[j])));
        else error = 1e9;
        double score_error = std::abs(actual.score - expected_score);
        max_error = std::max(max_error, error); max_score_error = std::max(max_score_error, score_error);
        ok = ok && error <= 0.0005 && score_error <= 0.00005;
        if (ok) ++passed;
        else std::cerr << "FAIL case " << i << ": " << question << "; expected_id=" << expected_id << ", actual_id=" << actual.answer_id << ", max_logit_error=" << error << '\n';
        total_ms += actual.milliseconds;
    }
    if (reference.f.peek() != std::char_traits<char>::eof()) throw std::runtime_error("Trailing reference data");
    std::cout << std::setprecision(9) << "{\"passed\":" << passed << ",\"total\":" << count << ",\"max_logit_error\":" << max_error << ",\"max_score_error\":" << max_score_error << ",\"total_inference_ms\":" << total_ms << ",\"runtime\":\""
#ifdef KAPRAO_NEON
              << "neon"
#else
              << "scalar"
#endif
              << "\"}\n";
    return passed == count ? 0 : 1;
}

int run(const std::vector<std::string>& args) {
    std::string model_path = "model/kaprao_fp32.bin", question, test_path, gen_path, gen_test_path;
    bool json = false, batch = false, raw = false, have_question = false, debug = false;
    int benchmark = 0;
    float temperature = 0.0f;
    unsigned seed = std::random_device{}();
    for (size_t i = 1; i < args.size(); ++i) {
        auto value = [&]() { if (i + 1 >= args.size()) throw std::runtime_error("Missing value for " + args[i]); return args[++i]; };
        if (args[i] == "--model") model_path = value();
        else if (args[i] == "--self-test") test_path = value();
        else if (args[i] == "--ask") { question = value(); have_question = true; }
        else if (args[i] == "--json") json = true;
        else if (args[i] == "--batch-json") { batch = true; json = true; }
        else if (args[i] == "--raw") raw = true;
        else if (args[i] == "--gen") gen_path = value();
        else if (args[i] == "--gen-self-test") gen_test_path = value();
        else if (args[i] == "--temperature") { temperature = std::stof(value()); if (!(temperature >= 0.0f && temperature <= 5.0f)) throw std::runtime_error("temperature must be between 0 and 5"); }
        else if (args[i] == "--seed") seed = static_cast<unsigned>(std::stoul(value()));
        else if (args[i] == "--debug") debug = true;
        else if (args[i] == "--benchmark") { benchmark = std::stoi(value()); if (benchmark < 1 || benchmark > 10000) throw std::runtime_error("benchmark must be between 1 and 10000"); }
        else if (args[i] == "--help" || args[i] == "-h") {
            std::cout << "KapraoTiny CPU: --model FILE [--gen GEN_FILE] [--ask UTF8_QUESTION] [--json] [--benchmark N]\n"
                         "--gen FILE: hybrid mode, the generator writes answers (--temperature T, 0 = greedy; --seed N; --debug shows the guard)\n"
                         "--self-test FILE: verify classifier references; --gen-self-test FILE: verify generator references (needs --gen)\n"
                         "--batch-json: one question per stdin line; --raw: developer-only logits without scope rejection\n"; return 0;
        } else throw std::runtime_error("Unknown option: " + args[i]);
    }
    if (batch && (have_question || benchmark)) throw std::runtime_error("batch-json cannot be combined with ask/benchmark");
    if (benchmark && !have_question) throw std::runtime_error("benchmark requires --ask");
    Model model(model_path);
    std::unique_ptr<Generator> generator;
    if (!gen_path.empty()) generator = std::make_unique<Generator>(gen_path);
    std::mt19937 rng(seed);
    auto answer = [&](const std::string& q) { return hybrid_predict(model, generator.get(), q, raw, temperature, rng); };
    auto show = [&](const Prediction& p, const char* prefix) {
        if (json) { print_prediction(p); return; }
        std::cout << prefix << p.response << '\n';
        if (debug) std::cout << std::setprecision(3) << "   {source: " << p.source << ", answer_id: " << p.answer_id << ", score: " << p.score << ", similarity: " << p.similarity << ", ms: " << p.milliseconds << "}\n";
    };
    if (!test_path.empty() || !gen_test_path.empty()) {
        if (have_question || batch || benchmark) throw std::runtime_error("self-test cannot be combined with ask/batch/benchmark");
        int status = test_path.empty() ? 0 : self_test(model, test_path);
        if (!gen_test_path.empty()) {
            if (!generator) throw std::runtime_error("gen-self-test needs --gen");
            status |= generator_self_test(model, *generator, gen_test_path);
        }
        return status;
    }
    if (have_question) {
        Prediction p = answer(question);
        show(p, "");
        if (benchmark) {
            if (p.logits.empty()) throw std::runtime_error("Benchmark needs a question accepted by the model");
            std::vector<double> times;
            for (int i = 0; i < benchmark; ++i) times.push_back(answer(question).milliseconds);
            double mean = std::accumulate(times.begin(), times.end(), 0.0) / times.size();
            std::sort(times.begin(), times.end());
            std::cerr << (generator ? "Hybrid inference" : "Inference only") << ", model already loaded: mean_ms=" << mean << ", p50_ms=" << times[times.size() / 2] << ", p95_ms=" << times[static_cast<size_t>(std::ceil(times.size() * 0.95)) - 1] << ", runs=" << times.size() << '\n';
        }
        return 0;
    }
    if (!batch) std::cout << u8"ถามเรื่องกะเพราได้เลย ภาษาไทยหรือ English (พิมพ์ exit เพื่อออก)" << '\n';
    std::string line;
    while (true) {
        if (!batch) std::cout << u8"คุณ: " << std::flush;
        if (!std::getline(std::cin, line)) break;
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (!batch && (line == "exit" || line == "quit" || line == u8"ออก")) break;
        try { show(answer(line), "KapraoTiny: "); }
        catch (const std::exception& e) {
            if (!batch) std::cerr << e.what() << '\n';
            else std::cout << "{\"status\":\"error\",\"error\":" << json_string(e.what()) << "}\n";
        }
    }
    return 0;
}

#ifdef _WIN32
std::string utf8(const wchar_t* text) {
    int n = WideCharToMultiByte(CP_UTF8, 0, text, -1, nullptr, 0, nullptr, nullptr);
    std::string out(static_cast<size_t>(n), '\0');
    WideCharToMultiByte(CP_UTF8, 0, text, -1, out.data(), n, nullptr, nullptr); out.pop_back(); return out;
}
int wmain(int argc, wchar_t** argv) {
    SetConsoleCP(CP_UTF8); SetConsoleOutputCP(CP_UTF8);
    std::vector<std::string> args; for (int i = 0; i < argc; ++i) args.push_back(utf8(argv[i]));
    try { return run(args); } catch (const std::exception& e) { std::cerr << "Error: " << e.what() << '\n'; return 1; }
}
#else
int main(int argc, char** argv) {
    try { return run(std::vector<std::string>(argv, argv + argc)); } catch (const std::exception& e) { std::cerr << "Error: " << e.what() << '\n'; return 1; }
}
#endif
