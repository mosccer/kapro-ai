"""Generate binary self-test vectors from the original PyTorch model."""
import hashlib
import json
import struct
import sys
from pathlib import Path

import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import kaprao
import kaprao_hybrid as hybrid
from export_model import u32, string, strings


def main():
    torch.set_num_threads(4)
    model, checkpoint = kaprao.loaded_model()
    data = kaprao.load_data()
    questions = []
    for split in ('train', 'validation', 'test', 'legacy_test', 'new_topic_test', 'en_test', 'unsupported_test'):
        questions.extend((r['question'], split, r['answer_id']) for r in data[split])
    for name in ('fresh_test', 'new_topic_fresh', 'v3_fresh'):
        for r in json.loads((HERE.parent / 'data' / f'{name}_questions.json').read_text(encoding='utf-8')):
            questions.append((r['question'], name, r['answer_id']))
    for q in json.loads((HERE.parent / 'data' / 'out_of_scope_questions.json').read_text(encoding='utf-8')):
        questions.append((q, 'out_of_scope', None))
    for q in ['', '   ', '\t', 'ผัดกระเพราใส่อะไรบ้าง', ' ผัด กะเพรา ใส่ อะไร บ้าง ', 'กะเพรา\u00a0ใส่อะไร', 'กะเพรา\u2003ใส่อะไร', 'กะเพรา\u3000คืออะไร', 'กะเพรา😀', 'กะเพรา ABC xyz', 'กะเพรา İ Σ Ä Ω', 'ผัดกระ เพราใส่อะไรบ้าง', 'x' * 65 + 'กะเพรา', 'กะเพรา' + 'x' * 100, 'ผัดหมูกระเทียมใส่อะไรบ้าง', 'กะเพราใช้ส่วนผสมอะไรครับ', 'ควรผัดพริกกระเทียมหรือเนื้อก่อน', 'แกงป่าใส่อะไรบ้าง', 'ผัดขี้เมาใส่อะไร', 'โป๊ะแตกคืออะไร', 'ตุลสีคืออะไร', 'Ocimum sanctum คือกะเพราไหม', 'WHAT IS  HOLY   BASIL?', ' pad kra pao recipe ', 'Pad Krapow 2 plates?', 'holy basil vs thai basil', 'Tell me about pizza', 'กะเพรา holy basil คืออะไร', 'Drunken noodles ingredients', 'İs holy basil Ωk', 'hi', 'Hello!', ' HEY  there ', 'Good morning.', 'สวัสดีครับ', 'หวัดดีค่ะ',
              'สวัสดี ครับผม!', 'ดีจ้า', 'hi kaprao', 'hello, what is holy basil?', 'สวัสดีครับ กะเพราคืออะไร', 'ครับ', 'ดีมาก',
              'สวัสดีครับกะเพราใส่อะไร', 'Hi! What goes into pad kaprao?', 'hippo kaprao', '  Hello there, holy basil?', 'หวัดดีค่ะ, ปลูกกะเพรายังไง',
              'ทำอะไรได้บ้าง', 'ถามอะไรได้บ้างครับ', 'ทำ อะไร ได้ บ้าง?', 'สวัสดีครับ ทำอะไรได้บ้าง', 'What can you do?', 'HELP',
              'Hi, what can I ask?', 'help me with kaprao', 'กะเพราทำอะไรได้บ้าง']:
        questions.append((q, 'edge_case', None))
    rows = []
    for q, split, label in questions:
        greeting = kaprao.is_greeting(q)
        q_model = q if greeting else kaprao.strip_greeting(q)
        tokens = kaprao.tokenize(q_model)[:model.max_len]
        ids = [checkpoint['vocab'].get(token, 1) for token in tokens]
        if greeting:
            status, answer_id, score, logits = 'greeting', -1, 0.0, []
        elif kaprao.is_help(q_model):
            status, answer_id, score, logits = 'help', -1, 0.0, []
        elif not tokens:
            status, answer_id, score, logits = 'empty', -1, 0.0, []
        elif not kaprao.is_in_scope(q_model, model.max_len):
            status, answer_id, score, logits = 'out_of_scope', -1, 0.0, []
        else:
            with torch.no_grad():
                output = model(torch.tensor([kaprao.encode(q_model, checkpoint['vocab'])]))[0]
                confidence, index = output.softmax(0).max(0)
            score, answer_id, logits = confidence.item(), index.item(), output.tolist()
            status = 'unsupported' if answer_id == checkpoint.get('unknown_answer_id') else ('answer' if score >= 0.35 else 'low_confidence')
        rows.append({'question': q, 'split': split, 'label': label, 'ids': ids, 'status': status, 'answer_id': answer_id, 'score': score, 'logits': logits, 'response': kaprao.ask(q, model, checkpoint)})
    # Additional raw classifier vectors cover scope rejection without conflating it
    # with correctness of the numerical Transformer implementation.
    for q in ['', 'ผัดหมูกระเทียมใส่อะไรบ้าง', 'x' * 65 + 'กะเพรา']:
        with torch.no_grad():
            output = model(torch.tensor([kaprao.encode(q, checkpoint['vocab'])]))[0]
            score, answer_id = output.softmax(0).max(0)
        rows.append({'question': q, 'split': 'raw_numerics', 'raw': True, 'label': None, 'ids': [checkpoint['vocab'].get(t, 1) for t in kaprao.tokenize(q)[:model.max_len]], 'status': 'unsupported' if answer_id.item() == checkpoint.get('unknown_answer_id') else ('answer' if score.item() >= .35 else 'low_confidence'), 'answer_id': answer_id.item(), 'score': score.item(), 'logits': output.tolist(), 'response': None})
    out = HERE / 'tests'
    out.mkdir(exist_ok=True)
    with (out / 'reference.bin').open('wb') as f:
        f.write(b'KAPTEST1')
        u32(f, len(rows))
        for row in rows:
            u32(f, int(row.get('raw', False)))
            string(f, row['question'])
            string(f, row['status'])
            u32(f, row['answer_id'] & 0xffffffff)
            f.write(struct.pack('<f', row['score']))
            u32(f, len(row['ids']))
            for token in row['ids']:
                u32(f, token)
            u32(f, len(row['logits']))
            for logit in row['logits']:
                f.write(struct.pack('<f', logit))
    (out / 'reference.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')
    manifest = {'cases': len(rows), 'reference_sha256': hashlib.sha256((out / 'reference.bin').read_bytes()).hexdigest(), 'checkpoint_sha256': hashlib.sha256((HERE.parent / 'kaprao_model.pt').read_bytes()).hexdigest()}
    (out / 'reference_manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print(f'Generated {len(rows)} reference cases from Python.')
    make_generator_reference(model, checkpoint, rows, out)


def make_generator_reference(classifier, cls_checkpoint, rows, out):
    # Greedy generator output for questions the classifier answers, plus first-step logits.
    generator, gen_checkpoint = hybrid.loaded_generator()
    vocab = gen_checkpoint['vocab']
    cases = [(kaprao.strip_greeting(r['question']), r['answer_id']) for r in rows if r['status'] == 'answer' and r['split'] in ('validation', 'fresh_test', 'new_topic_test', 'new_topic_fresh', 'v3_fresh', 'en_test', 'edge_case')]
    # One question per category with a mismatched category, to cover every class token.
    cases += [(q, answer_id) for answer_id in hybrid.CLASS_IDS for q in ('กะเพราคืออะไร', 'What is kaprao?')]
    gen_rows = []
    for question, answer_id in cases:
        prompt = hybrid.prompt_ids(question, answer_id, vocab)
        with torch.no_grad():
            first = generator(torch.tensor([prompt]))[0, -1].tolist()
        text, finished = hybrid.generate(generator, vocab, question, answer_id)
        gen_rows.append({'question': question, 'answer_id': answer_id, 'prompt': prompt, 'text': text, 'finished': finished, 'similarity': hybrid.similarity(text, answer_id, kaprao.language(question)), 'first_logits': first})
    with (out / 'gen_reference.bin').open('wb') as f:
        f.write(b'KAPGTST1')
        u32(f, len(gen_rows))
        for row in gen_rows:
            string(f, row['question'])
            u32(f, row['answer_id'])
            u32(f, len(row['prompt']))
            for token in row['prompt']:
                u32(f, token)
            string(f, row['text'])
            u32(f, int(row['finished']))
            f.write(struct.pack('<f', row['similarity']))
            u32(f, len(row['first_logits']))
            for logit in row['first_logits']:
                f.write(struct.pack('<f', logit))
    (out / 'gen_reference.json').write_text(json.dumps(gen_rows, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'Generated {len(gen_rows)} generator reference cases from Python.')


if __name__ == '__main__':
    main()
