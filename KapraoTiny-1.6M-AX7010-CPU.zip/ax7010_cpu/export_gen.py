"""Export the hybrid generator (kaprao_gen.pt) to a standalone little-endian FP32 file."""
import argparse
from array import array
import hashlib
import json
import struct
import sys
from pathlib import Path

import torch

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
sys.path.insert(0, str(PROJECT))
import kaprao
import kaprao_hybrid as hybrid
from export_model import string, strings, u32


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, default=hybrid.GEN_PATH)
    parser.add_argument('--output', type=Path, default=HERE / 'model' / 'kaprao_gen_fp32.bin')
    args = parser.parse_args()
    checkpoint = torch.load(args.checkpoint, map_location='cpu', weights_only=True)
    model = hybrid.TinyGPT(len(checkpoint['vocab']), **checkpoint['config'])
    model.load_state_dict(checkpoint['model'])
    model.eval()
    layer = model.blocks.layers[0]
    if layer.activation is not torch.nn.functional.relu or not layer.norm_first:
        raise ValueError('C++ generator supports pre-norm ReLU layers only.')
    if model.head.weight.data_ptr() != model.token.weight.data_ptr() or model.head.bias is not None:
        raise ValueError('C++ generator expects the output head tied to the token embedding.')
    cfg = checkpoint['config']
    vocab = checkpoint['vocab']
    if sorted(vocab.values()) != list(range(len(vocab))) or [t for t, i in sorted(vocab.items(), key=lambda x: x[1])][:len(hybrid.SPECIAL)] != hybrid.SPECIAL:
        raise ValueError('Unexpected generator vocabulary layout.')
    ordered_vocab = [token for token, _ in sorted(vocab.items(), key=lambda item: item[1])]
    class_ids = hybrid.CLASS_IDS
    tokens = [vocab[hybrid.class_token(i)] for i in class_ids]
    if tokens != list(range(len(hybrid.SPECIAL), len(hybrid.SPECIAL) + len(class_ids))):
        raise ValueError('Class tokens must follow the special tokens.')
    tensors = {k: v for k, v in model.state_dict().items() if k != 'head.weight'}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('wb') as stream:
        stream.write(b'KAPGEN1\0')
        u32(stream, 2)
        for key in ('dim', 'layers', 'heads', 'ffn', 'max_len'):
            u32(stream, cfg[key])
        u32(stream, len(vocab))
        u32(stream, hybrid.MAX_QUESTION)
        u32(stream, hybrid.MAX_ANSWER)
        # Guard attempts when sampling; the guard itself is an exact match to the sentences below.
        stream.write(struct.pack('<fff', layer.norm1.eps, float(hybrid.GUARD_ATTEMPTS), cfg['dim'] ** 0.5))
        strings(stream, ordered_vocab)
        strings(stream, kaprao.LEXICON)
        # Answer IDs the generator can write, in class-token order, each with its verified Thai and
        # English sentences for the guard. Language tokens <th>, <en> follow the class tokens.
        if [vocab[f'<{lang}>'] for lang in hybrid.LANGUAGES] != [len(hybrid.SPECIAL) + len(class_ids) + i for i in range(2)]:
            raise ValueError('Language tokens must follow the class tokens.')
        u32(stream, len(class_ids))
        for answer_id in class_ids:
            u32(stream, answer_id)
            for lang in hybrid.LANGUAGES:
                strings(stream, hybrid.GUARD_VARIANTS[lang][answer_id])
        u32(stream, len(tensors))
        for name, tensor in tensors.items():
            flat = tensor.detach().cpu().contiguous().float()
            if not torch.isfinite(flat).all():
                raise ValueError('Non-finite tensor: ' + name)
            string(stream, name)
            u32(stream, flat.ndim)
            for size in flat.shape:
                u32(stream, size)
            values = array('f', flat.view(-1).tolist())
            if sys.byteorder != 'little':
                values.byteswap()
            raw = values.tobytes()
            u32(stream, len(raw))
            stream.write(raw)
    manifest = {
        'format': 'KAPGEN1, version 2, little-endian FP32 (Thai + English)',
        'sha256': hashlib.sha256(args.output.read_bytes()).hexdigest(),
        'bytes': args.output.stat().st_size,
        'parameters': sum(t.numel() for t in tensors.values()),
        'config': cfg,
        'vocabulary_size': len(vocab),
        'answer_ids': class_ids,
        'max_answer_tokens': hybrid.MAX_ANSWER,
        'guard': 'exact match to one of the exported sentences',
        'guard_attempts_when_sampling': hybrid.GUARD_ATTEMPTS,
        'guard_sentences': {lang: sum(len(v) for v in hybrid.GUARD_VARIANTS[lang].values()) for lang in hybrid.LANGUAGES},
        'selected_epoch': checkpoint['epoch'],
        'dataset_sha256': checkpoint['dataset_sha256'],
        'checkpoint_sha256': hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(),
        'runtime': 'ARMv7 Linux on AX7010 CPU; FP32; KV-cache decoding; no PyTorch needed',
    }
    args.output.with_suffix('.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'Exported generator {manifest["parameters"]:,} parameters; {manifest["bytes"]:,} bytes')


if __name__ == '__main__':
    main()
