param(
    [Parameter(Mandatory=$true)][string]$Compiler,
    [ValidateSet('windows','arm-neon','arm-scalar')][string]$Target = 'windows'
)
$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    New-Item -ItemType Directory -Force -Path 'bin' | Out-Null
    $taskFlags = @('-std=c++17', '-O3', '-ffp-contract=off', '-Wall', '-Wextra')
    if ($Target -eq 'windows') {
        $taskFlags += @('-municode', '-static')
        $taskOutput = 'bin/kaprao_cpu.exe'
    } else {
        $taskFlags += @('-mcpu=cortex-a9', '-mfpu=neon', '-mfloat-abi=hard', '-static', '-static-libgcc', '-static-libstdc++', '-Wno-psabi')
        if ($Target -eq 'arm-neon') {
            $taskFlags += '-DKAPRAO_NEON'
            $taskOutput = 'bin/kaprao_ax7010'
        } else {
            $taskOutput = 'bin/kaprao_ax7010_scalar'
        }
    }
    & $Compiler @taskFlags 'kaprao_cpu.cpp' '-o' $taskOutput
    if ($LASTEXITCODE -ne 0) { throw "Build failed with exit code $LASTEXITCODE" }
    if ($Target -ne 'windows') {
        $taskStrip = $Compiler -replace 'g\+\+\.exe$', 'strip.exe'
        if (($taskStrip -ne $Compiler) -and (Test-Path -LiteralPath $taskStrip)) {
            & $taskStrip '--strip-all' $taskOutput
            if ($LASTEXITCODE -ne 0) { throw "Strip failed with exit code $LASTEXITCODE" }
        }
    }
    Write-Output "Built $taskOutput"
} finally {
    Pop-Location
}
