"""Export trained KapraoTiny to a standalone little-endian FP32 model file."""
import argparse
from array import array
import hashlib
import json
import struct
import sys
from pathlib import Path

import torch

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
sys.path.insert(0, str(PROJECT))
import kaprao


def u32(stream, value):
    stream.write(struct.pack('<I', value))


def string(stream, value):
    encoded = value.encode('utf-8')
    u32(stream, len(encoded))
    stream.write(encoded)


def strings(stream, values):
    u32(stream, len(values))
    for value in values:
        string(stream, value)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, default=PROJECT / 'kaprao_model.pt')
    parser.add_argument('--output', type=Path, default=HERE / 'model' / 'kaprao_fp32.bin')
    args = parser.parse_args()
    checkpoint = torch.load(args.checkpoint, map_location='cpu', weights_only=True)
    if checkpoint.get('tokenizer_version') != 'thai-terms-v5-en':
        raise ValueError('This exporter requires the thai-terms-v5-en checkpoint.')
    model = kaprao.TinyTransformer(len(checkpoint['vocab']), len(checkpoint['answers']), **checkpoint['config'])
    model.load_state_dict(checkpoint['model'])
    model.eval()
    if model.encoder.layers[0].activation is not torch.nn.functional.relu:
        raise ValueError('C++ runner supports ReLU activation only.')
    cfg = checkpoint['config']
    vocab = checkpoint['vocab']
    if sorted(vocab.values()) != list(range(len(vocab))):
        raise ValueError('Vocabulary IDs are not contiguous.')
    ordered_vocab = [token for token, _ in sorted(vocab.items(), key=lambda item: item[1])]
    # Export Python's Unicode whitespace/lowercase semantics rather than relying on
    # the C++ locale installed on the embedded board.
    whitespace = []
    lowercase = []
    for codepoint in range(sys.maxunicode + 1):
        if 0xD800 <= codepoint <= 0xDFFF:
            continue
        char = chr(codepoint)
        if char.isspace():
            whitespace.append(char)
        if char.lower() != char:
            lowercase.append((char, char.lower()))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    tensors = model.state_dict()
    with args.output.open('wb') as stream:
        stream.write(b'KAPRAO1\0')
        u32(stream, 5)
        for key in ('dim', 'layers', 'heads', 'ffn', 'max_len'):
            u32(stream, cfg[key])
        u32(stream, len(vocab))
        u32(stream, len(checkpoint['answers']))
        u32(stream, checkpoint['unknown_answer_id'])
        stream.write(struct.pack('<fff', model.encoder.layers[0].norm1.eps, 0.35, cfg['dim'] ** 0.5))
        strings(stream, ordered_vocab)
        strings(stream, kaprao.LEXICON)
        strings(stream, checkpoint['answers'])
        strings(stream, [kaprao.OUT_OF_SCOPE_MESSAGE, 'กรุณาพิมพ์คำถามเรื่องกะเพรา', 'ยังไม่มั่นใจคำตอบ', 'ลองถามเรื่องกะเพราให้เจาะจงขึ้น'])
        strings(stream, sorted(kaprao.SCOPE_TERMS))
        english = kaprao.messages('en')
        strings(stream, checkpoint['answers_en'])
        strings(stream, [english['out_of_scope'], english['empty'], english['low_confidence'], english['be_specific']])
        # Format 5: greeting words, polite endings, punctuation and replies (Thai, English).
        strings(stream, sorted(kaprao.GREETINGS))
        strings(stream, kaprao.GREETING_PARTICLES)
        strings(stream, list(kaprao.GREETING_PUNCTUATION))
        strings(stream, [kaprao.messages('th')['greeting'], english['greeting']])
        strings(stream, kaprao.GREETING_PREFIXES)
        strings(stream, sorted(kaprao.HELP_PHRASES))
        strings(stream, [kaprao.messages('th')['help'], english['help']])
        strings(stream, whitespace)
        u32(stream, len(lowercase))
        for source, dest in lowercase:
            string(stream, source)
            string(stream, dest)
        u32(stream, len(tensors))
        for name, tensor in tensors.items():
            flat = tensor.detach().cpu().contiguous().float()
            if not torch.isfinite(flat).all():
                raise ValueError('Non-finite tensor: ' + name)
            string(stream, name)
            u32(stream, flat.ndim)
            for size in flat.shape:
                u32(stream, size)
            values = array('f', flat.view(-1).tolist())
            if values.itemsize != 4:
                raise ValueError('Exporter requires 32-bit floats')
            if sys.byteorder != 'little':
                values.byteswap()
            raw = values.tobytes()
            u32(stream, len(raw))
            stream.write(raw)
    manifest = {
        'format': 'KAPRAO1, version 5, little-endian FP32 (Thai + English, greetings)',
        'sha256': hashlib.sha256(args.output.read_bytes()).hexdigest(),
        'bytes': args.output.stat().st_size,
        'parameters': sum(t.numel() for t in tensors.values()),
        'config': cfg,
        'vocabulary_size': len(vocab),
        'answer_classes': len(checkpoint['answers']),
        'unknown_answer_id': checkpoint['unknown_answer_id'],
        'scope_terms': sorted(kaprao.SCOPE_TERMS),
        'selected_epoch': checkpoint['epoch'],
        'dataset_sha256': checkpoint['dataset_sha256'],
        'checkpoint_sha256': hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(),
        'tokenizer_version': checkpoint['tokenizer_version'],
        'runtime': 'ARMv7 Linux on AX7010 CPU; FP32; no PyTorch needed',
    }
    args.output.with_suffix('.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'Exported {manifest["parameters"]:,} parameters; {manifest["bytes"]:,} bytes')


if __name__ == '__main__':
    main()
