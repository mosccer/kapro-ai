"""Build tests/board_questions.tsv from the Python reference outputs.

The expected status and Answer ID come from tests/reference.json, which
make_reference.py produced with the PyTorch checkpoint. The board script
compares only status and Answer ID; scores may differ slightly between
PyTorch, scalar C++ and NEON.
"""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REFERENCE = HERE / 'tests' / 'reference.json'
OUTPUT = HERE / 'tests' / 'board_questions.tsv'


def pick(cases):
    rows = []
    # One held-out question per category that Python answers correctly (categories without one are skipped).
    fresh = [c for c in cases if c['split'] in ('fresh_test', 'new_topic_fresh', 'new_topic_test') and c['status'] == 'answer' and c['answer_id'] == c['label']]
    for answer_id in sorted({c['answer_id'] for c in fresh}):
        case = next(c for c in fresh if c['answer_id'] == answer_id)
        rows.append(('answer', case))
    english = [c for c in cases if c['split'] == 'en_test' and c['answer_id'] == c['label']]
    rows += [('english', c) for c in english[:8]]
    unsupported = [c for c in cases if c['split'] == 'unsupported_test' and c['status'] == 'unsupported' and c['answer_id'] == c['label']]
    rows += [('unsupported', c) for c in unsupported[:4]]
    rows += [('out_of_scope', c) for c in cases if c['split'] == 'out_of_scope'][:3]
    rows += [('spelling', c) for c in cases if c['split'] == 'edge_case' and c['question'] == 'ผัดกระเพราใส่อะไรบ้าง']
    return rows


def main():
    cases = json.loads(REFERENCE.read_text(encoding='utf-8'))
    lines = ['# id\tgroup\texpected_status\texpected_answer_id\tquestion']
    for n, (group, case) in enumerate(pick(cases), 1):
        question = case['question']
        if '\t' in question or '\n' in question or not question.strip():
            raise ValueError(f'Question cannot be stored in TSV: {question!r}')
        lines.append(f"Q{n:02d}\t{group}\t{case['status']}\t{case['answer_id']}\t{question}")
    OUTPUT.write_bytes(('\n'.join(lines) + '\n').encode('utf-8'))
    print(f'Wrote {len(lines) - 1} questions to {OUTPUT.relative_to(HERE)}')


if __name__ == '__main__':
    main()
