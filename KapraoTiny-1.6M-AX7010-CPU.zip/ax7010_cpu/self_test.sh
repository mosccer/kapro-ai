#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
chmod +x bin/kaprao_ax7010 2>/dev/null || true
./bin/kaprao_ax7010 --model model/kaprao_fp32.bin --self-test tests/reference.bin
./bin/kaprao_ax7010 --model model/kaprao_fp32.bin --gen model/kaprao_gen_fp32.bin --gen-self-test tests/gen_reference.bin
