# KapraoTiny สำหรับ CPU ของ ALINX AX7010

แพ็กเกจนี้มีโมเดลที่ฝึกแล้วและโปรแกรม C++ สำหรับ ARM Cortex-A9 บน **Linux ของ AX7010** เป็นระบบแบบผสม (hybrid):

1. **Classifier** (Transformer 3 ชั้น, 1,802,784 พารามิเตอร์) เลือกหมวดคำตอบ 1 ใน 31 หมวด หรือปฏิเสธคำถามที่ไม่มีข้อมูล
2. **Generator** (Transformer แบบ decoder 4 ชั้น, 1,635,584 พารามิเตอร์) แต่งคำตอบของหมวดนั้นทีละ token ด้วย KV cache
3. **ตัวตรวจ (guard)** แสดงข้อความที่แต่งก็ต่อเมื่อตรงกับประโยคที่ตรวจข้อเท็จจริงแล้วของหมวดนั้นทุกตัวอักษร (รวมประโยคที่ไม่ได้ใช้ฝึก) ถ้าใช้ `--temperature` จะให้แต่งใหม่ได้ 3 ครั้ง ถ้ายังไม่ผ่านจะใช้คำตอบที่เตรียมไว้แทน

**รองรับภาษาไทยและภาษาอังกฤษ:** ถามเป็นภาษาอังกฤษ (มีตัวอักษรละตินและไม่มีอักษรไทย) จะได้คำตอบภาษาอังกฤษ เช่น `--ask "What is jungle curry?"` คำถามภาษาอังกฤษต้องมีคำอย่าง kaprao, krapow, holy basil, tulsi, drunken noodles, jungle curry หรือ po taek

**คำทักทายและคำถามช่วยเหลือ:** พิมพ์ทักทายอย่างเดียว เช่น `สวัสดีครับ` หรือ `hi` จะได้คำทักทายตอบกลับ พิมพ์ `ทำอะไรได้บ้าง` หรือ `What can you do?` จะได้รายการหัวข้อที่ถามได้ ถ้าขึ้นต้นด้วยคำทักทายแล้วถามต่อ เช่น `สวัสดีครับ กะเพราคืออะไร` โปรแกรมจะตัดคำทักทายออกก่อนส่งให้โมเดล

ใส่ `--gen model/kaprao_gen_fp32.bin` เพื่อเปิด Generator ถ้าไม่ใส่ โปรแกรมจะตอบด้วยคำตอบที่เตรียมไว้อย่างเดียวเหมือนรุ่นก่อน คำถามต้องมีคำว่า กะเพรา/กระเพรา หรือชื่อเมนู ผัดขี้เมา แกงป่า โป๊ะแตก

**ยังไม่ได้ทดลองกับบอร์ดจริง** ตัวรัน C++ บน Windows เทียบกับ Python แล้ว ส่วนไฟล์ ARM build สำเร็จและตรวจ ELF header แล้ว ต้องรัน `sh board_test.sh` บนบอร์ดก่อนใช้งาน ดูขั้นตอนใน [รันบน AX7010 ทีละขั้น](#รันบน-ax7010-ทีละขั้น)

## ทดลอง C++ บนคอมพิวเตอร์ได้ทันที

เปิด PowerShell:

```powershell
cd "C:\Users\User\OneDrive\Desktop\โปรเจค ALINX AX7010\KapraoTiny-1.6M\ax7010_cpu"
.\bin\kaprao_cpu.exe --gen model/kaprao_gen_fp32.bin --ask "แกงป่าใส่อะไรบ้าง"
.\bin\kaprao_cpu.exe --gen model/kaprao_gen_fp32.bin --debug
.\bin\kaprao_cpu.exe --gen model/kaprao_gen_fp32.bin --temperature 0.8
```

พิมพ์ `exit` เพื่อออก โปรแกรมนี้ไม่ต้องใช้ Python หรือ PyTorch `--debug` แสดงว่าคำตอบมาจาก generator, fallback หรือ classifier พร้อมคะแนนตัวตรวจ ส่วน `--temperature 0.8` ทำให้ถ้อยคำเปลี่ยนไปในแต่ละครั้ง (ค่าเริ่มต้น 0 คือเลือกคำที่มั่นใจที่สุดเสมอ)

ตรวจคำตอบและการคำนวณกับชุดอ้างอิงจาก Python:

```powershell
.\bin\kaprao_cpu.exe --self-test tests/reference.bin
.\bin\kaprao_cpu.exe --gen model/kaprao_gen_fp32.bin --gen-self-test tests/gen_reference.bin
```

ต้องเห็น `"passed":1973,"total":1973` และ `"generator_passed":419,"total":419` (ข้อความที่แต่งตรงกับ Python ทุกตัวอักษร) รายงานอยู่ใน `CPP_TEST_RESULTS.json`

## รันบน AX7010 ทีละขั้น

บอร์ดต้องบูต Linux สำหรับ ARMv7 ได้ก่อน (เช่น PetaLinux จาก SD card) ไฟล์ที่ให้เป็น executable Linux 32 บิต ARM EABI5 hard-float แบบ static link และต้องใช้ Linux ABI 3.2.0 ขึ้นไป โปรแกรมนี้ไม่ใช่ `BOOT.BIN` และไม่ได้ใช้ FPGA accelerator

### ขั้นที่ 1: ตรวจแพ็กเกจบนคอมก่อนคัดลอก

```powershell
cd "C:\Users\User\OneDrive\Desktop\โปรเจค ALINX AX7010\KapraoTiny-1.6M\ax7010_cpu"
python check_package.py
```

ต้องเห็น `PC checks passed` โดยไม่มีบรรทัด `[FAIL]` คำสั่งนี้สร้าง `SHA256SUMS` (ใช้ LF) และ `AX7010_CPU_READY.zip` ใหม่ และเขียนผลตรวจลง `PACKAGE_CHECK.json` ถ้าแก้ไฟล์ในแพ็กเกจ ต้องรันคำสั่งนี้ใหม่ก่อนคัดลอกทุกครั้ง

### ขั้นที่ 2: เปิด terminal ของบอร์ด

ต่อสาย USB-UART ของบอร์ดเข้าคอม เปิด Device Manager เพื่อดูหมายเลข `COMx` แล้วเปิด PuTTY หรือ Tera Term แบบ Serial, `115200` baud, `8N1`, ไม่มี flow control และตั้ง character set เป็น `UTF-8` เพื่อให้แสดงภาษาไทยได้ จากนั้นเปิดบอร์ดแล้ว login (PetaLinux มักใช้ผู้ใช้ `root` หรือ `petalinux` ขึ้นกับ image)

### ขั้นที่ 3: คัดลอกไฟล์ไปยังบอร์ด (เลือกวิธีเดียว)

**ทางเลือก A: ผ่าน Ethernet ด้วย SCP** ต่อสาย LAN ระหว่างบอร์ดกับ router หรือคอม แล้วดู IP บน terminal ของบอร์ด:

```sh
ip addr
```

ดูบรรทัด `inet` ของ `eth0` เช่น `192.168.1.10` จากนั้นรันบน PowerShell ของคอม (เปลี่ยน IP เป็นค่าจริง):

```powershell
scp "C:\Users\User\OneDrive\Desktop\โปรเจค ALINX AX7010\KapraoTiny-1.6M\ax7010_cpu\AX7010_CPU_READY.zip" root@192.168.1.10:/home/root/
```

**ทางเลือก B: ผ่าน SD card หรือ USB drive** คัดลอก `AX7010_CPU_READY.zip` ลงในการ์ด แล้วเสียบที่บอร์ด จากนั้นรันบนบอร์ด:

```sh
mkdir -p /mnt/usb
mount /dev/mmcblk0p1 /mnt/usb
cp /mnt/usb/AX7010_CPU_READY.zip /home/root/
umount /mnt/usb
```

ถ้าใช้ USB drive ให้เปลี่ยน `/dev/mmcblk0p1` เป็น `/dev/sda1` (ดูชื่อได้ด้วย `ls /dev/mmcblk* /dev/sd*`) ถ้าระบบ mount การ์ดไว้แล้วที่ `/run/media/...` หรือ `/media/...` ให้คัดลอกจาก path นั้นได้เลย ต้องคัดลอก zip ออกจาก partition FAT มายัง `/home/root` เพราะ partition FAT มักไม่เก็บสิทธิ์ execute

### ขั้นที่ 4: แตกไฟล์บนบอร์ด

```sh
cd /home/root
unzip -o AX7010_CPU_READY.zip
cd ax7010_cpu
```

ถ้าบอร์ดไม่มีคำสั่ง `unzip` ให้แตก zip บนคอมแล้วคัดลอกทั้งโฟลเดอร์ด้วย `scp -r` แทน:

```powershell
scp -r "C:\path\to\extracted\ax7010_cpu" root@192.168.1.10:/home/root/
```

### ขั้นที่ 5: รันชุดทดสอบบนบอร์ด

```sh
sh board_test.sh
```

สคริปต์ทำงานตามลำดับ:

1. แสดง `uname -m`, NEON ใน `/proc/cpuinfo` และหน่วยความจำ
2. ตรวจว่ามีไฟล์ครบ
3. ตรวจ `sha256sum -c SHA256SUMS` และข้ามขั้นนี้พร้อมแจ้ง WARN ถ้าไม่มีคำสั่งนั้น
4. ตั้ง `chmod +x` และตรวจว่าโปรแกรมเปิดได้
5. รัน self-test ของ Classifier 1973 กรณีเทียบกับ Python ถ้าไม่ผ่าน จะลอง scalar ต่อเพื่อแยกปัญหา แล้วรัน self-test ของ Generator 419 กรณี
6. ถาม 46 คำถามใน `tests/board_questions.tsv` ด้วยโหมด hybrid แล้วเทียบสถานะและ Answer ID
7. วัดความเร็วโหมด hybrid 20 รอบ

บรรทัดสุดท้ายต้องเป็น `RESULT: PASS` ผลทั้งหมดถูกบันทึกใน `board_test_result.txt` ให้คัดลอกไฟล์นี้กลับมาเก็บเป็นหลักฐาน:

```powershell
scp root@192.168.1.10:/home/root/ax7010_cpu/board_test_result.txt .
```

ถ้าต้องการตรวจเร็วโดยไม่รัน self-test และไม่วัดความเร็ว ให้ใช้ `sh board_test.sh --quick`

### ขั้นที่ 6: ทดลองถามตอบ

ถามครั้งเดียว:

```sh
./bin/kaprao_ax7010 --gen model/kaprao_gen_fp32.bin --ask "ผัดกะเพราใส่อะไรบ้าง"
./bin/kaprao_ax7010 --gen model/kaprao_gen_fp32.bin --ask "ใครเป็นคนคิดเมนูกระเพราคนแรก"
./bin/kaprao_ax7010 --gen model/kaprao_gen_fp32.bin --ask "แกงป่าใส่อะไรบ้าง" --json
```

โหมดโต้ตอบ (พิมพ์ `exit` เพื่อออก):

```sh
./bin/kaprao_ax7010 --gen model/kaprao_gen_fp32.bin --debug
```

ตัวอย่างคำถามอื่นอยู่ในคอลัมน์สุดท้ายของ `tests/board_questions.tsv` คำตอบที่ควรได้บน PC เป็นดังนี้ โดยค่าคะแนนบนบอร์ดอาจต่างได้เล็กน้อย:

| คำถาม | ผลที่คาดหวัง |
|---|---|
| `ผัดกะเพราใส่อะไรบ้าง` | Answer ID 1: Generator แต่งคำตอบเรื่องใบกะเพรา กระเทียม พริก เนื้อสัตว์หรือโปรตีน และเครื่องปรุงรส |
| `ใครเป็นคนคิดเมนูกระเพราคนแรก` | Answer ID 21: ไม่มีหลักฐานชัดเจนว่าใครคิดค้น เชื่อกันว่าเริ่มราวสมัยรัชกาลที่ 7 ... |
| `กะเพรารักษามะเร็งได้ไหม` | หมวดปฏิเสธ (ID 16): ยังไม่มีข้อมูลตอบคำถามนี้ ... |
| `ผัดหมูกระเทียมใส่อะไรบ้าง` | นอกขอบเขต: คำถามนี้อยู่นอกขอบเขต ตอนนี้ตอบได้เฉพาะเรื่องกะเพรา |

ถ้าภาษาไทยแสดงเป็นตัวอักษรแปลก ๆ ให้ตั้ง terminal เป็น UTF-8 และลองรัน `export LANG=C.UTF-8`

วัดความเร็วแยกด้วยคำสั่งด้านล่าง ค่า `mean_ms`, `p50_ms` และ `p95_ms` วัดตั้งแต่ tokenize จนได้คำตอบหลังโหลดโมเดลแล้ว ไม่รวมเวลาเปิดโปรแกรม ตัดคำว่า `--gen ...` ออกเพื่อวัดเฉพาะ Classifier:

```sh
./bin/kaprao_ax7010 --gen model/kaprao_gen_fp32.bin --ask "ผัดกะเพราใส่อะไรบ้าง" --benchmark 20
```

บน PC (Windows, scalar) โหมด hybrid ใช้ราว 95 ms ต่อคำตอบ บน Cortex-A9 คาดว่าช้ากว่านั้นหลายเท่า ตัวเลขจริงต้องวัดบนบอร์ด

ถ้าเวอร์ชัน NEON ไม่ผ่าน self-test ให้เก็บ `board_test_result.txt` แล้วใช้เวอร์ชัน scalar แทน:

```sh
KAPRAO_BIN=bin/kaprao_ax7010_scalar sh board_test.sh
```

## ไฟล์ที่ต้องใช้บนบอร์ด

| ไฟล์ | หน้าที่ |
|---|---|
| `bin/kaprao_ax7010` | โปรแกรม ARM Linux ที่ใช้ NEON สำหรับ dot product |
| `bin/kaprao_ax7010_scalar` | โปรแกรม ARM Linux ทางเลือกแบบ scalar |
| `model/kaprao_fp32.bin` | Classifier: น้ำหนัก, config, tokenizer, Unicode normalization, คำที่ถือว่าอยู่ในขอบเขต และคำตอบทั้งหมด |
| `model/kaprao_gen_fp32.bin` | Generator: น้ำหนัก, vocabulary และคำตอบตัวอย่างที่ตัวตรวจใช้เทียบ |
| `tests/reference.bin` | ชุดอ้างอิง Classifier 1973 กรณีสำหรับ self-test โดยไม่ต้องมี Python |
| `tests/gen_reference.bin` | ชุดอ้างอิง Generator 419 กรณี (ข้อความที่ต้องแต่งได้ตรงกับ Python) |
| `tests/board_questions.tsv` | 46 คำถามพร้อมสถานะและ Answer ID ที่คาดหวังจาก Python |
| `board_test.sh` | สคริปต์ทดสอบบนบอร์ด (POSIX sh/BusyBox) |
| `self_test.sh` | รันเฉพาะ self-test ของทั้งสองโมเดล |
| `SHA256SUMS` | Checksum ของทุกไฟล์ในแพ็กเกจ (LF) |

ไฟล์บน PC: `check_package.py` ตรวจแพ็กเกจ, `export_model.py` และ `export_gen.py` ส่งออกโมเดล, `make_reference.py` สร้างชุดอ้างอิง, `make_board_questions.py` สร้างชุดคำถามจาก `tests/reference.json`

สองโมเดลรวมประมาณ 3.44 ล้านพารามิเตอร์ ไฟล์ Classifier ประมาณ 7.3 MB และ Generator ประมาณ 6.7 MB เมื่อโหลดทั้งคู่ใช้ RAM ราว 14 MB สำหรับน้ำหนัก บวก KV cache ราว 1.6 MB และ buffers อื่น ไม่ต้องลง PyTorch, ONNX Runtime หรือไลบรารี inference อื่นบนบอร์ด ยังไม่ได้ quantize เป็น INT8

## สร้าง executable ใหม่

ไฟล์พร้อมใช้มีให้แล้ว การ build จำเป็นเมื่อแก้ source code เท่านั้น

บน Windows ใช้ compiler แบบพกพาที่รองรับ target ที่ต้องการ:

```powershell
powershell -ExecutionPolicy Bypass -File .\build_windows.ps1 -Compiler "C:\path\to\clang++.exe" -Target windows
powershell -ExecutionPolicy Bypass -File .\build_windows.ps1 -Compiler "C:\path\to\arm-none-linux-gnueabihf-g++.exe" -Target arm-neon
powershell -ExecutionPolicy Bypass -File .\build_windows.ps1 -Compiler "C:\path\to\arm-none-linux-gnueabihf-g++.exe" -Target arm-scalar
```

รุ่นที่ให้ build ด้วย LLVM MinGW สำหรับ Windows และ Arm GNU Toolchain 13.3.Rel1 สำหรับ ARM Linux

บนเครื่อง Linux ที่มี cross compiler:

```sh
make arm ARM_CXX=arm-linux-gnueabihf-g++
make arm-scalar ARM_CXX=arm-linux-gnueabihf-g++
```

หรือใช้ `make arm ARM_CXX=arm-none-linux-gnueabihf-g++` ถ้าใช้ Arm GNU Toolchain อย่าเลือก compiler `arm-none-eabi-g++` เพราะเป็น target bare-metal

ตัว source ใช้ C++17 standard library; คำสั่ง build ตั้ง `-mcpu=cortex-a9 -mfpu=neon -mfloat-abi=hard` และใช้ static linking หาก toolchain อื่นไม่มี static libraries ให้ใช้ SDK ที่มีไลบรารีตรง target หรือ build ด้วย sysroot ของ Linux บนบอร์ด

## ส่งออกใหม่หลังฝึกโมเดลใหม่

บนคอมพิวเตอร์ที่มี PyTorch จากโฟลเดอร์นี้:

```powershell
python export_model.py
python make_reference.py
python verify_cpp.py
```

exporter รับ checkpoint `../kaprao_model.pt` และตรวจ tokenizer version คำสั่ง export จะเขียนทับไฟล์โมเดลและ manifest คำสั่งสร้าง references จะเขียนทับข้อมูลอ้างอิง ต้องส่งทั้งโมเดลกับ references รุ่นใหม่ไปด้วย และสร้าง `SHA256SUMS` ใหม่สำหรับไฟล์ที่เปลี่ยน

## ขอบเขตและผลตรวจ

Classifier เลือกหนึ่งใน 31 หมวดคำตอบและ 1 หมวดปฏิเสธคำถามที่ยังไม่มีข้อมูล ทุกคำถามต้องระบุ `กะเพรา`, `กระเพรา` หรือชื่อเมนูที่รองรับ โปรแกรมไม่จำบริบทการสนทนา การตรวจคำเหล่านี้เป็นเงื่อนไขของโปรแกรม ไม่ได้รับประกันว่าคำถามจะอยู่ในหมวดที่รองรับ Generator เขียนได้เฉพาะเนื้อหาในหมวดที่ Classifier เลือก และตัวตรวจป้องกันไม่ให้ข้อความที่ห่างจากฐานความรู้ถูกแสดง

softmax ที่แสดงเป็น `คะแนนโมเดล` ใช้เลือกหมวด ไม่ใช่โอกาสตอบถูก ข้อมูลทดสอบเป็นคำถามที่เขียนขึ้นเอง คะแนน Classifier: ชุดเดิม 13/16 (81.2%), ชุดสุดท้าย 30/32 (93.8%), หัวข้อใหม่ 27/34 (79.4%), หัวข้อใหม่ที่ไม่ใช้ปรับแต่ง 14/19 (73.7%) และปฏิเสธถูก 17/23 (73.9%) ดูรายละเอียดใน `../evaluation_report.json`

self-test ตรวจ token IDs, Answer ID, สถานะตอบ/ปฏิเสธ, logits และคะแนน กำหนดความคลาดเคลื่อน logits ไม่เกิน `5e-4` และคะแนนไม่เกิน `5e-5` เนื่องจากลำดับการรวมเลข FP32 ระหว่าง scalar, PyTorch และ NEON อาจต่างกัน มี raw numerical cases สำหรับอินพุตว่างและคำถามที่ปกติถูกปฏิเสธ โดย raw mode ใช้สำหรับการตรวจเท่านั้น

| การตรวจ | สถานะ | ที่ไหน |
|---|---|---|
| Python unittest 23 ข้อ (`test_project`, `test_hybrid`) | ผ่าน 21, **ไม่ผ่าน 2** (อัตราปฏิเสธต่ำกว่า 80% และคำถามราคากะเพราหมูสับไม่ถูกปฏิเสธ) | PC |
| C++ Classifier (Windows, scalar) เทียบ Python 1973 กรณี | ผ่าน 1973/1973 | PC (`check_package.py`, `CPP_TEST_RESULTS.json`) |
| C++ Generator (Windows, scalar) เทียบ Python 419 กรณี | ผ่าน 419/419, ข้อความตรงทุกกรณี | PC (`check_package.py`, `CPP_TEST_RESULTS.json`) |
| Windows CLI, UTF-8 และโหมดโต้ตอบ | ผ่าน | PC (`verify_cpp.py`) |
| ARM ELF32, EABI5 hard-float, static (ไม่มี PT_INTERP) | ผ่าน | PC (อ่าน header ไฟล์, `BUILD_MANIFEST.json`) |
| Hash โมเดล/reference/checkpoint ตรงกัน, `SHA256SUMS` และ zip | ผ่าน | PC (`PACKAGE_CHECK.json`) |
| `board_test.sh` dry run ด้วย Windows exe (46/46 คำถาม, โหมด hybrid) | ผ่าน | PC (Git Bash) |
| รัน ARM binary บน Cortex-A9 ของ AX7010 | **ยังไม่ได้ทดสอบ** | ต้องรันบนบอร์ด |
| NEON numerical parity (self-test ทั้งสองโมเดลบน ARM) | **ยังไม่ได้ทดสอบ** | ต้องรันบนบอร์ด |
| ความเร็วและหน่วยความจำบน AX7010 | **ยังไม่ได้วัด** | ต้องรันบนบอร์ด |
| การแสดงภาษาไทยผ่าน UART | **ยังไม่ได้ทดสอบ** | ต้องรันบนบอร์ด |

อ้างอิง: [AMD Cortex-A9 NEON](https://docs.amd.com/r/en-US/ug585-zynq-7000-SoC-TRM/NEON), [Arm GNU Toolchain](https://developer.arm.com/Tools%20and%20Software/GNU%20Toolchain), [Arm GNU 13.3.Rel1 Release Note](https://documentation-service.arm.com/static/66bb3acb882fec713ef48f84), [LLVM MinGW](https://github.com/mstorsjo/llvm-mingw/releases/tag/20260922)

## ถ้าเปิดโปรแกรมบนบอร์ดไม่ได้

| ข้อความ | วิธีตรวจ |
|---|---|
| `Permission denied` | ใช้ `chmod +x` และคัดลอกโปรแกรมออกจาก partition ที่ mount แบบ noexec ไปยังโฟลเดอร์ Linux ที่อนุญาตให้รัน |
| `Exec format error` | ตรวจว่าเลือก `bin/kaprao_ax7010` และบอร์ดบูต Linux ARMv7 ไม่ใช่ไฟล์ Windows `.exe` |
| `Cannot open model` | เข้าโฟลเดอร์ `ax7010_cpu` ก่อนรัน หรือระบุ `--model` พร้อม path จริง |
| self-test ไม่ผ่าน | ตรวจ `SHA256SUMS` และให้โมเดลกับ reference เป็นรุ่นเดียวกัน เก็บผล error ก่อนลอง scalar |
| `sha256sum` แจ้ง `FAILED open or read` ทุกไฟล์ | `SHA256SUMS` มี CRLF จาก Windows ให้รัน `python check_package.py` บนคอมแล้วคัดลอก zip ใหม่ |
| `unzip: not found` | แตก zip บนคอมแล้วคัดลอกทั้งโฟลเดอร์ด้วย `scp -r` |
| ภาษาไทยเป็นตัวอักษรแปลก | ตั้ง terminal เป็น UTF-8 และรัน `export LANG=C.UTF-8` |

## รุ่นที่รองรับหมวดปฏิเสธ

โมเดลรุ่นนี้มี 17 outputs: Answer ID 0–15 เป็นคำตอบเดิม และ ID 16 เป็นหมวด `ยังไม่มีข้อมูล` ใช้เพื่อปฏิเสธคำถามนอกฐานความรู้ เช่น ผู้คิดค้นเมนู ไม่ใช่การเพิ่มคำตอบเกี่ยวกับประวัติศาสตร์

ไฟล์น้ำหนักเป็น KAPRAO1 format version 2 ซึ่งเพิ่ม unknown-answer ID ใน header ตัวรัน C++ รุ่นนี้รองรับทั้ง version 1 และ 2 ตัวรันรุ่นเก่าจะไม่อ่าน version 2 ให้คัดลอกทั้ง executable, model และ reference จากแพ็กเกจล่าสุดไปด้วย

ชุดทดสอบหมวดปฏิเสธที่ไม่ได้ใช้ฝึกได้ 29/32 ข้อ (90.6%) คำถามนอกฐานความรู้แบบใหม่ยังอาจพลาดได้ การตรวจชื่อกะเพราก่อนเรียกโมเดลยังคงใช้สำหรับคำถามที่ไม่ระบุหัวข้อ
