"""Check standalone C++ output against frozen PyTorch references (standard library only)."""
import argparse
import hashlib
import json
import os
import platform
import subprocess
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--exe', type=Path, default=HERE / 'bin' / ('kaprao_cpu.exe' if os.name == 'nt' else 'kaprao_ax7010'))
    parser.add_argument('--report', type=Path, default=HERE / 'CPP_TEST_RESULTS.json')
    args = parser.parse_args()
    exe = args.exe.resolve()
    model = HERE / 'model' / 'kaprao_fp32.bin'
    manifest = json.loads(model.with_suffix('.json').read_text(encoding='utf-8'))
    references = json.loads((HERE / 'tests' / 'reference.json').read_text(encoding='utf-8'))
    reference_manifest = json.loads((HERE / 'tests' / 'reference_manifest.json').read_text(encoding='utf-8'))
    assert digest(model) == manifest['sha256'], 'Model checksum mismatch'
    assert digest(HERE / 'tests' / 'reference.bin') == reference_manifest['reference_sha256'], 'Reference checksum mismatch'
    assert reference_manifest['checkpoint_sha256'] == manifest['checkpoint_sha256'], 'Model and reference checkpoints differ'
    actuals = {}
    for raw in (False, True):
        indexes = [i for i, row in enumerate(references) if row.get('raw', False) == raw]
        cases = [references[i] for i in indexes]
        # Tabs are fine in a line; a newline in a question would split the protocol.
        assert all('\n' not in row['question'] and '\r' not in row['question'] for row in cases)
        command = [str(exe), '--model', str(model), '--batch-json'] + (['--raw'] if raw else [])
        result = subprocess.run(command, input=''.join(row['question'] + '\n' for row in cases), encoding='utf-8', capture_output=True, check=True, timeout=600)
        rows = [json.loads(line) for line in result.stdout.splitlines()]
        assert len(rows) == len(cases), 'Output case count mismatch'
        actuals.update(zip(indexes, rows))
    max_error, max_score_error = 0.0, 0.0
    groups = {}
    failures = []
    for i, expected in enumerate(references):
        actual = actuals[i]
        checks = [actual.get('status') == expected['status'], actual.get('answer_id') == expected['answer_id'], actual.get('ids') == expected['ids']]
        logits = actual.get('logits', [])
        checks.append(len(logits) == len(expected['logits']))
        error = max((abs(a - b) for a, b in zip(logits, expected['logits'])), default=0.0)
        score_error = abs(actual.get('score', -1) - expected['score'])
        max_error, max_score_error = max(max_error, error), max(max_score_error, score_error)
        checks += [error <= 0.0005, score_error <= 0.00005]
        if expected['response'] is not None:
            checks.append(actual.get('response') == expected['response'])
        if not all(checks):
            failures.append({'index': i, 'question': expected['question'], 'actual': actual, 'max_logit_error': error})
        group = groups.setdefault(expected['split'], {'total': 0, 'matching_python': 0, 'correct_answer_id': 0, 'answered_correct': 0})
        group['total'] += 1
        group['matching_python'] += int(all(checks))
        if expected['label'] is not None:
            correct = actual.get('answer_id') == expected['label']
            group['correct_answer_id'] += int(correct)
            group['answered_correct'] += int(correct and actual.get('status') == 'answer')
    # Real CLI invocations cover Unicode arguments/paths and interactive operation.
    question = 'ผัดกะเพราใส่อะไรบ้าง'
    result = subprocess.run([str(exe), '--model', str(model), '--ask', question, '--json'], capture_output=True, encoding='utf-8', check=True, timeout=120)
    assert json.loads(result.stdout)['answer_id'] == 1
    result = subprocess.run([str(exe), '--model', str(model)], input=question + '\nผัดหมูกระเทียมใส่อะไรบ้าง\nexit\n', capture_output=True, encoding='utf-8', check=True, timeout=120)
    assert result.stdout.count('KapraoTiny:') == 2
    assert 'คำถามนี้อยู่นอกขอบเขต' in result.stdout
    with tempfile.TemporaryDirectory(prefix='kaprao-check-') as temporary:
        truncated = Path(temporary) / 'truncated.bin'
        truncated.write_bytes(model.read_bytes()[:30])
        result = subprocess.run([str(exe), '--model', str(truncated), '--ask', question], capture_output=True, encoding='utf-8', timeout=120)
        assert result.returncode != 0 and 'Truncated model' in result.stderr
        result = subprocess.run([str(exe), '--model', str(truncated.with_name('missing.bin'))], capture_output=True, encoding='utf-8', timeout=120)
        assert result.returncode != 0 and 'Cannot open model' in result.stderr
    self_test = subprocess.run([str(exe), '--model', str(model), '--self-test', str(HERE / 'tests' / 'reference.bin')], capture_output=True, encoding='utf-8', check=True, timeout=600)
    report = {
        'host': platform.platform(), 'machine': platform.machine(),
        'executable': exe.name, 'executable_sha256': digest(exe),
        'model_sha256': digest(model), 'model_bytes': model.stat().st_size,
        'cases': len(references), 'passed': len(references) - len(failures),
        'max_logit_error': max_error, 'max_score_error': max_score_error,
        'groups': groups, 'failures': failures,
        'standalone_self_test': json.loads(self_test.stdout),
        'cli_checks': ['Thai Unicode arguments', 'interactive Q&A', 'out-of-scope rejection', 'truncated model rejected', 'missing model rejected'],
        'physical_ax7010_tested': False,
        'note': 'Host CPU comparison only. ARM executable architecture is verified separately; hardware latency and NEON numerical parity require board self-test.',
    }
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f"C++ matches Python: {report['passed']}/{report['cases']}; max logit error={max_error:.8g}")
    for split in ('legacy_test', 'test', 'fresh_test'):
        group = groups[split]
        print(f"{split}: {group['correct_answer_id']}/{group['total']} correct Answer IDs")
    if failures:
        raise SystemExit('Parity failures; see report')


if __name__ == '__main__':
    main()
